﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using НайтиРаботу;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        private AddResumeForm form;
        private EditResumeForm form2;
        [TestInitialize]
        public void Setup()
        {
            form = new AddResumeForm();
        }

        public void Setup2()
        {
            form2 = new EditResumeForm();
        }

        [TestMethod]
        public void Test_pictureBox_addresume_Click_AddsResumeSuccessfully()
        {
            AuthForm.UserId = 1;
            form.textBox_name.Text = "Test Name";
            form.textBox_mail.Text = "test@example.com";
            form.textBox_dol.Text = "Developer";
            form.textBox_sal.Text = "1000";
            form.comboBox_edu.SelectedItem = "Bachelor";
            form.comboBox_grafik.SelectedItem = "Full-Time";

            Assert.AreEqual(string.Empty, form.textBox_name.Text);
            Assert.AreEqual(string.Empty, form.textBox_mail.Text);
            Assert.AreEqual(string.Empty, form.textBox_dol.Text);
            Assert.AreEqual(string.Empty, form.textBox_sal.Text);
        }
    }
}
