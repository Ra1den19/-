﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class MyOtklikiForm : Form
    {
        int userId = AuthForm.UserId;
        public MyOtklikiForm()
        {
            InitializeComponent();
            toolTip_delete.SetToolTip(pictureBox_delete, "Отменить отклик");
        }

        private void MyOtklikiForm_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select Отклики.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы ], Отрасль, Зарплата, Образование from Вакансии inner join Отклики on Вакансии.КодВакансии = Отклики.КодВакансии where Отклики.КодПользователя = '{userId}'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox_find_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string find = textBox_find.Text.Trim();
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select Отклики.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join Отклики on Вакансии.КодВакансии = Отклики.КодВакансии where Отклики.КодПользователя = '{userId}' and Специализация like '%{find}%'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"delete from Отклики where КодВакансии = '{id}'; select Отклики.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join Отклики on Вакансии.КодВакансии = Отклики.КодВакансии where Отклики.КодПользователя = '{userId}'";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Отклик отменён", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_delete_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_delete.BackColor = Color.Silver;
        }

        private void pictureBox_delete_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_delete.BackColor = Color.White;
        }
    }
}
