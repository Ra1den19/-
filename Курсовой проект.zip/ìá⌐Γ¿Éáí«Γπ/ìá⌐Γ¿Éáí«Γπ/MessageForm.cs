﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class MessageForm : Form
    {
        int userId = AuthForm.UserId;
        public MessageForm()
        {
            InitializeComponent();
        }

        private void pictureBox_confirm_Click(object sender, EventArgs e)
        {
            try
            {
                SendMessage();
                Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SendMessage()
        {
            try
            {
                string mail = textMail.Text;
                string message = textBox_mes.Text;
                string smtpServer = "smtp.gmail.com";
                int smtpPort = 587;
                string smtpUsername = "boxtrend56@gmail.com";
                string smtpPassword = "ppiz tezw jzwd dcgk";

                using (SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort))
                {
                    smtpClient.Credentials = new NetworkCredential(smtpUsername, smtpPassword);
                    smtpClient.EnableSsl = true;

                    using (MailMessage mailMessage = new MailMessage())
                    {
                        mailMessage.From = new MailAddress(smtpUsername);
                        mailMessage.To.Add($"{mail}");
                        mailMessage.Subject = "Приглашение";
                        mailMessage.Body = $"{message}";

                        try
                        {
                            smtpClient.Send(mailMessage);
                            MessageBox.Show("Сообщение успешно отправлено.", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Ошибка отправки сообщения: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
