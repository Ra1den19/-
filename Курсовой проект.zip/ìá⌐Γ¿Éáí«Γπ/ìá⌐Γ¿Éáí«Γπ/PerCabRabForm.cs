﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class PerCabRabForm : Form
    {
        int userId = AuthForm.UserId;

        public PerCabRabForm()
        {
            InitializeComponent();
            toolTip_add.SetToolTip(pictureBox_addvacancy, "Добавить");
            toolTip_edit.SetToolTip(pictureBox_editvacancy, "Изменить");
        }

        private void PerCabRabForm_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], Отрасль, Зарплата, Образование, ГрафикРаботы as [График работы], Статус from Вакансии where КодПользователя = '{userId}'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_addvacancy_Click(object sender, EventArgs e)
        {
            AddVacancyForm avf = new AddVacancyForm();
            avf.ShowDialog();
        }

        private void pictureBox_editvacancy_Click(object sender, EventArgs e)
        {
            EditVacancyForm ev = new EditVacancyForm();
            ev.Show();
        }

        private void pictureBox_addvacancy_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_addvacancy.BackColor = Color.Silver;
        }

        private void pictureBox_addvacancy_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_addvacancy.BackColor = Color.White;
        }

        private void pictureBox_editvacancy_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_editvacancy.BackColor = Color.Silver;
        }

        private void pictureBox_editvacancy_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_editvacancy.BackColor = Color.White;
        }
    }
}
