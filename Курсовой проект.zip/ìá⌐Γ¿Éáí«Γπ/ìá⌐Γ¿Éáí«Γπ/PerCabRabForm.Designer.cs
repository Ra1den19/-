﻿namespace НайтиРаботу
{
    partial class PerCabRabForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ОтображениеДанных = new System.Windows.Forms.DataGridView();
            this.toolTip_add = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_edit = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_delete = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox_editvacancy = new System.Windows.Forms.PictureBox();
            this.pictureBox_addvacancy = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_editvacancy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addvacancy)).BeginInit();
            this.SuspendLayout();
            // 
            // ОтображениеДанных
            // 
            this.ОтображениеДанных.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.ОтображениеДанных.BackgroundColor = System.Drawing.Color.White;
            this.ОтображениеДанных.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ОтображениеДанных.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ОтображениеДанных.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ОтображениеДанных.DefaultCellStyle = dataGridViewCellStyle2;
            this.ОтображениеДанных.Location = new System.Drawing.Point(12, 12);
            this.ОтображениеДанных.MultiSelect = false;
            this.ОтображениеДанных.Name = "ОтображениеДанных";
            this.ОтображениеДанных.ReadOnly = true;
            this.ОтображениеДанных.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ОтображениеДанных.Size = new System.Drawing.Size(914, 347);
            this.ОтображениеДанных.TabIndex = 1;
            // 
            // pictureBox_editvacancy
            // 
            this.pictureBox_editvacancy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_editvacancy.Image = global::НайтиРаботу.Properties.Resources.Edit;
            this.pictureBox_editvacancy.Location = new System.Drawing.Point(77, 373);
            this.pictureBox_editvacancy.Name = "pictureBox_editvacancy";
            this.pictureBox_editvacancy.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_editvacancy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_editvacancy.TabIndex = 5;
            this.pictureBox_editvacancy.TabStop = false;
            this.pictureBox_editvacancy.Click += new System.EventHandler(this.pictureBox_editvacancy_Click);
            this.pictureBox_editvacancy.MouseEnter += new System.EventHandler(this.pictureBox_editvacancy_MouseEnter);
            this.pictureBox_editvacancy.MouseLeave += new System.EventHandler(this.pictureBox_editvacancy_MouseLeave);
            // 
            // pictureBox_addvacancy
            // 
            this.pictureBox_addvacancy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_addvacancy.Image = global::НайтиРаботу.Properties.Resources.Add_New;
            this.pictureBox_addvacancy.Location = new System.Drawing.Point(12, 373);
            this.pictureBox_addvacancy.Name = "pictureBox_addvacancy";
            this.pictureBox_addvacancy.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_addvacancy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_addvacancy.TabIndex = 4;
            this.pictureBox_addvacancy.TabStop = false;
            this.pictureBox_addvacancy.Click += new System.EventHandler(this.pictureBox_addvacancy_Click);
            this.pictureBox_addvacancy.MouseEnter += new System.EventHandler(this.pictureBox_addvacancy_MouseEnter);
            this.pictureBox_addvacancy.MouseLeave += new System.EventHandler(this.pictureBox_addvacancy_MouseLeave);
            // 
            // PerCabRabForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(954, 458);
            this.Controls.Add(this.pictureBox_editvacancy);
            this.Controls.Add(this.pictureBox_addvacancy);
            this.Controls.Add(this.ОтображениеДанных);
            this.Name = "PerCabRabForm";
            this.Text = "PerCabRabForm";
            this.Load += new System.EventHandler(this.PerCabRabForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_editvacancy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addvacancy)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox_editvacancy;
        private System.Windows.Forms.PictureBox pictureBox_addvacancy;
        private System.Windows.Forms.ToolTip toolTip_add;
        private System.Windows.Forms.ToolTip toolTip_edit;
        private System.Windows.Forms.ToolTip toolTip_delete;
        public System.Windows.Forms.DataGridView ОтображениеДанных;
    }
}