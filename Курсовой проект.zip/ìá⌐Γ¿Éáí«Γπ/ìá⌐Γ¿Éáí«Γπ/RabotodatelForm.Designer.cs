﻿namespace НайтиРаботу
{
    partial class RabotodatelForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RabotodatelForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolTip_exit = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_logout = new System.Windows.Forms.ToolTip(this.components);
            this.label_version = new System.Windows.Forms.Label();
            this.pictureBox_logout = new System.Windows.Forms.PictureBox();
            this.pictureBox_closeapp = new System.Windows.Forms.PictureBox();
            this.resumes_button = new System.Windows.Forms.Button();
            this.myotkliki_button = new System.Windows.Forms.Button();
            this.favresumes_button = new System.Windows.Forms.Button();
            this.percab_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_logout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_closeapp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(212, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(943, 492);
            this.panel1.TabIndex = 22;
            // 
            // label_version
            // 
            this.label_version.AutoSize = true;
            this.label_version.BackColor = System.Drawing.Color.Green;
            this.label_version.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_version.Location = new System.Drawing.Point(1, 488);
            this.label_version.Name = "label_version";
            this.label_version.Size = new System.Drawing.Size(39, 13);
            this.label_version.TabIndex = 23;
            this.label_version.Text = "Ver 1.0";
            // 
            // pictureBox_logout
            // 
            this.pictureBox_logout.BackColor = System.Drawing.Color.Green;
            this.pictureBox_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_logout.Image = global::НайтиРаботу.Properties.Resources.Open_Door;
            this.pictureBox_logout.Location = new System.Drawing.Point(166, 431);
            this.pictureBox_logout.Name = "pictureBox_logout";
            this.pictureBox_logout.Size = new System.Drawing.Size(40, 40);
            this.pictureBox_logout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_logout.TabIndex = 21;
            this.pictureBox_logout.TabStop = false;
            this.pictureBox_logout.Click += new System.EventHandler(this.pictureBox_logout_Click);
            this.pictureBox_logout.MouseEnter += new System.EventHandler(this.pictureBox_logout_MouseEnter);
            this.pictureBox_logout.MouseLeave += new System.EventHandler(this.pictureBox_logout_MouseLeave);
            // 
            // pictureBox_closeapp
            // 
            this.pictureBox_closeapp.BackColor = System.Drawing.Color.Green;
            this.pictureBox_closeapp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_closeapp.Image = global::НайтиРаботу.Properties.Resources.Shutdown;
            this.pictureBox_closeapp.Location = new System.Drawing.Point(6, 431);
            this.pictureBox_closeapp.Name = "pictureBox_closeapp";
            this.pictureBox_closeapp.Size = new System.Drawing.Size(40, 40);
            this.pictureBox_closeapp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_closeapp.TabIndex = 20;
            this.pictureBox_closeapp.TabStop = false;
            this.pictureBox_closeapp.Click += new System.EventHandler(this.pictureBox_closeapp_Click);
            this.pictureBox_closeapp.MouseEnter += new System.EventHandler(this.pictureBox_closeapp_MouseEnter);
            this.pictureBox_closeapp.MouseLeave += new System.EventHandler(this.pictureBox_closeapp_MouseLeave);
            // 
            // resumes_button
            // 
            this.resumes_button.BackColor = System.Drawing.Color.Green;
            this.resumes_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.resumes_button.FlatAppearance.BorderSize = 0;
            this.resumes_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.resumes_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.resumes_button.ForeColor = System.Drawing.Color.White;
            this.resumes_button.Image = global::НайтиРаботу.Properties.Resources.resume;
            this.resumes_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.resumes_button.Location = new System.Drawing.Point(0, 248);
            this.resumes_button.Name = "resumes_button";
            this.resumes_button.Size = new System.Drawing.Size(212, 40);
            this.resumes_button.TabIndex = 18;
            this.resumes_button.Text = "резюме";
            this.resumes_button.UseVisualStyleBackColor = false;
            this.resumes_button.Click += new System.EventHandler(this.resumes_button_Click);
            this.resumes_button.MouseEnter += new System.EventHandler(this.resumes_button_MouseEnter);
            this.resumes_button.MouseLeave += new System.EventHandler(this.resumes_button_MouseLeave);
            // 
            // myotkliki_button
            // 
            this.myotkliki_button.BackColor = System.Drawing.Color.Green;
            this.myotkliki_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myotkliki_button.FlatAppearance.BorderSize = 0;
            this.myotkliki_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myotkliki_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.myotkliki_button.ForeColor = System.Drawing.Color.White;
            this.myotkliki_button.Image = global::НайтиРаботу.Properties.Resources.Invites;
            this.myotkliki_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.myotkliki_button.Location = new System.Drawing.Point(0, 176);
            this.myotkliki_button.Name = "myotkliki_button";
            this.myotkliki_button.Size = new System.Drawing.Size(212, 40);
            this.myotkliki_button.TabIndex = 17;
            this.myotkliki_button.Text = "мои приглашения";
            this.myotkliki_button.UseVisualStyleBackColor = false;
            this.myotkliki_button.Click += new System.EventHandler(this.myotkliki_button_Click);
            this.myotkliki_button.MouseEnter += new System.EventHandler(this.myotkliki_button_MouseEnter);
            this.myotkliki_button.MouseLeave += new System.EventHandler(this.myotkliki_button_MouseLeave);
            // 
            // favresumes_button
            // 
            this.favresumes_button.BackColor = System.Drawing.Color.Green;
            this.favresumes_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.favresumes_button.FlatAppearance.BorderSize = 0;
            this.favresumes_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.favresumes_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.favresumes_button.ForeColor = System.Drawing.Color.White;
            this.favresumes_button.Image = global::НайтиРаботу.Properties.Resources.Favorite;
            this.favresumes_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.favresumes_button.Location = new System.Drawing.Point(0, 105);
            this.favresumes_button.Name = "favresumes_button";
            this.favresumes_button.Size = new System.Drawing.Size(212, 40);
            this.favresumes_button.TabIndex = 16;
            this.favresumes_button.Text = "избранные резюме";
            this.favresumes_button.UseVisualStyleBackColor = false;
            this.favresumes_button.Click += new System.EventHandler(this.favresumes_button_Click);
            this.favresumes_button.MouseEnter += new System.EventHandler(this.favresumes_button_MouseEnter);
            this.favresumes_button.MouseLeave += new System.EventHandler(this.favresumes_button_MouseLeave);
            // 
            // percab_button
            // 
            this.percab_button.BackColor = System.Drawing.Color.Green;
            this.percab_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.percab_button.FlatAppearance.BorderSize = 0;
            this.percab_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.percab_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.percab_button.ForeColor = System.Drawing.Color.White;
            this.percab_button.Image = global::НайтиРаботу.Properties.Resources.Man;
            this.percab_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.percab_button.Location = new System.Drawing.Point(0, 33);
            this.percab_button.Name = "percab_button";
            this.percab_button.Size = new System.Drawing.Size(212, 40);
            this.percab_button.TabIndex = 15;
            this.percab_button.Text = "личный кабинет";
            this.percab_button.UseVisualStyleBackColor = false;
            this.percab_button.Click += new System.EventHandler(this.percab_button_Click);
            this.percab_button.MouseEnter += new System.EventHandler(this.percab_button_MouseEnter);
            this.percab_button.MouseLeave += new System.EventHandler(this.percab_button_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Green;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(212, 504);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // RabotodatelForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1155, 504);
            this.Controls.Add(this.label_version);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox_logout);
            this.Controls.Add(this.pictureBox_closeapp);
            this.Controls.Add(this.resumes_button);
            this.Controls.Add(this.myotkliki_button);
            this.Controls.Add(this.favresumes_button);
            this.Controls.Add(this.percab_button);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1171, 543);
            this.MinimumSize = new System.Drawing.Size(1171, 543);
            this.Name = "RabotodatelForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Найти Работу";
            this.Load += new System.EventHandler(this.RabotodatelForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_logout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_closeapp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button percab_button;
        private System.Windows.Forms.Button favresumes_button;
        private System.Windows.Forms.Button myotkliki_button;
        private System.Windows.Forms.Button resumes_button;
        private System.Windows.Forms.PictureBox pictureBox_closeapp;
        private System.Windows.Forms.PictureBox pictureBox_logout;
        private System.Windows.Forms.ToolTip toolTip_exit;
        private System.Windows.Forms.ToolTip toolTip_logout;
        private System.Windows.Forms.Label label_version;
        public System.Windows.Forms.Panel panel1;
    }
}