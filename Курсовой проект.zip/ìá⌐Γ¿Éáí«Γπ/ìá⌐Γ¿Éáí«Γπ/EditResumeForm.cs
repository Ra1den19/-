﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class EditResumeForm : Form
    {
        int userId = AuthForm.UserId;
        public EditResumeForm()
        {
            InitializeComponent();
            toolTip_confirm.SetToolTip(pictureBox_confirm, "Подтвердить");
            toolTip_cancelorclose.SetToolTip(pictureBox_cancel, "Закрыть");
        }

        private void pictureBox_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EditResumeForm_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select КодРезюме as Номер, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Резюме where КодПользователя = '{userId}'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ОтображениеДанных_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    label_id.Text = selectedRow.Cells["Номер"].Value.ToString();
                    textBox_name.Text = selectedRow.Cells["Наименование"].Value.ToString();
                    textBox_dol.Text = selectedRow.Cells["Желаемая должность"].Value.ToString();
                    textBox_sal.Text = selectedRow.Cells["Зарплата"].Value.ToString();
                    comboBox_edu.SelectedItem = selectedRow.Cells["Образование"].Value.ToString();
                    textBox_mail.Text = selectedRow.Cells["Электронная почта"].Value.ToString();
                    comboBox_grafik.SelectedItem = selectedRow.Cells["График работы"].Value.ToString();
                    nav.Text = selectedRow.Cells["Профессиональные навыки и знания"].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void pictureBox_confirm_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string newValue1 = textBox_name.Text;
                    string newValue6 = textBox_dol.Text;
                    string newValue7 = textBox_sal.Text;
                    string newValue8 = comboBox_edu.SelectedItem.ToString();
                    string newValue3 = textBox_mail.Text;
                    string newValue9 = comboBox_grafik.SelectedItem.ToString();
                    string newValue10 = nav.Text;
                    string query = $"update Резюме set Наименование = '{newValue1}', ЖелаемаяДолжность = '{newValue6}', Зарплата = '{newValue7}', Образование = '{newValue8}', ЭлПочта = '{newValue3}', ГрафикРаботы = '{newValue9}', ПрофессиональныеНавыкиИЗнания = '{newValue10}' where КодРезюме = '{id}'; select КодРезюме as Номер, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Резюме where КодПользователя = '{userId}'";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Резюме обновлено", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void pictureBox_cancel_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_cancel.BackColor = Color.Silver;
        }

        private void pictureBox_cancel_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_cancel.BackColor = Color.White;
        }

        private void pictureBox_confirm_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_confirm.BackColor = Color.Silver;
        }

        private void pictureBox_confirm_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_confirm.BackColor = Color.White;
        }
    }
}
