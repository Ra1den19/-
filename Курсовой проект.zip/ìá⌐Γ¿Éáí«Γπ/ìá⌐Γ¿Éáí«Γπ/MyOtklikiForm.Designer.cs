﻿namespace НайтиРаботу
{
    partial class MyOtklikiForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ОтображениеДанных = new System.Windows.Forms.DataGridView();
            this.label_find = new System.Windows.Forms.Label();
            this.textBox_find = new System.Windows.Forms.TextBox();
            this.toolTip_delete = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox_delete = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_delete)).BeginInit();
            this.SuspendLayout();
            // 
            // ОтображениеДанных
            // 
            this.ОтображениеДанных.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.ОтображениеДанных.BackgroundColor = System.Drawing.Color.White;
            this.ОтображениеДанных.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ОтображениеДанных.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ОтображениеДанных.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ОтображениеДанных.DefaultCellStyle = dataGridViewCellStyle2;
            this.ОтображениеДанных.Location = new System.Drawing.Point(12, 12);
            this.ОтображениеДанных.MultiSelect = false;
            this.ОтображениеДанных.Name = "ОтображениеДанных";
            this.ОтображениеДанных.ReadOnly = true;
            this.ОтображениеДанных.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ОтображениеДанных.Size = new System.Drawing.Size(888, 268);
            this.ОтображениеДанных.TabIndex = 0;
            // 
            // label_find
            // 
            this.label_find.AutoSize = true;
            this.label_find.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_find.Location = new System.Drawing.Point(12, 298);
            this.label_find.Name = "label_find";
            this.label_find.Size = new System.Drawing.Size(58, 21);
            this.label_find.TabIndex = 20;
            this.label_find.Text = "Поиск";
            // 
            // textBox_find
            // 
            this.textBox_find.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_find.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_find.Location = new System.Drawing.Point(12, 322);
            this.textBox_find.Name = "textBox_find";
            this.textBox_find.Size = new System.Drawing.Size(477, 29);
            this.textBox_find.TabIndex = 21;
            this.textBox_find.TextChanged += new System.EventHandler(this.textBox_find_TextChanged);
            // 
            // pictureBox_delete
            // 
            this.pictureBox_delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_delete.Image = global::НайтиРаботу.Properties.Resources.Canceladd;
            this.pictureBox_delete.Location = new System.Drawing.Point(12, 382);
            this.pictureBox_delete.Name = "pictureBox_delete";
            this.pictureBox_delete.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_delete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_delete.TabIndex = 19;
            this.pictureBox_delete.TabStop = false;
            this.pictureBox_delete.Click += new System.EventHandler(this.pictureBox_delete_Click);
            this.pictureBox_delete.MouseEnter += new System.EventHandler(this.pictureBox_delete_MouseEnter);
            this.pictureBox_delete.MouseLeave += new System.EventHandler(this.pictureBox_delete_MouseLeave);
            // 
            // MyOtklikiForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(927, 465);
            this.Controls.Add(this.textBox_find);
            this.Controls.Add(this.label_find);
            this.Controls.Add(this.pictureBox_delete);
            this.Controls.Add(this.ОтображениеДанных);
            this.Name = "MyOtklikiForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MyOtklikiForm";
            this.Load += new System.EventHandler(this.MyOtklikiForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_delete)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ОтображениеДанных;
        private System.Windows.Forms.PictureBox pictureBox_delete;
        private System.Windows.Forms.Label label_find;
        private System.Windows.Forms.TextBox textBox_find;
        private System.Windows.Forms.ToolTip toolTip_delete;
    }
}