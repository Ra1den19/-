﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class FavResumesForm : Form
    {
        int userId = AuthForm.UserId;
        public FavResumesForm()
        {
            InitializeComponent();
            toolTip_delfav.SetToolTip(pictureBox_delfromfav, "Убрать из избранного");
        }

        private void button_otklik_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"insert into Приглашения(КодПользователя, КодРезюме) values('{userId}', '{id}'); select ИзбранныеРезюме.КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы from ИзбранныеРезюме inner join Резюме on ИзбранныеРезюме.КодРезюме = Резюме.КодРезюме inner join Пользователи on Резюме.КодПользователя = Пользователи.КодПользователя where ИзбранныеРезюме.КодПользователя = '{userId}'";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Приглашение отправлено", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_delfromfav_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"delete from ИзбранныеРезюме where КодРезюме = '{id}'; select ИзбранныеРезюме.КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы] from ИзбранныеРезюме inner join Резюме on ИзбранныеРезюме.КодРезюме = Резюме.КодРезюме inner join Пользователи on Резюме.КодПользователя = Пользователи.КодПользователя where ИзбранныеРезюме.КодПользователя = '{userId}'";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Резюме удалено из избранных", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FavResumesForm_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            string query = $"select ИзбранныеРезюме.КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы] from ИзбранныеРезюме inner join Резюме on ИзбранныеРезюме.КодРезюме = Резюме.КодРезюме inner join Пользователи on Резюме.КодПользователя = Пользователи.КодПользователя where ИзбранныеРезюме.КодПользователя = '{userId}'";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            ОтображениеДанных.DataSource = dt;
        }

        private void comboBox_sort_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                if (comboBox_sort.SelectedIndex == 0)
                {
                    string query = $"select ИзбранныеРезюме.КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы] from ИзбранныеРезюме inner join Резюме on ИзбранныеРезюме.КодРезюме = Резюме.КодРезюме inner join Пользователи on Резюме.КодПользователя = Пользователи.КодПользователя where ИзбранныеРезюме.КодПользователя = '{userId}' order by Зарплата";
                    SqlCommand command = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                }
                else if (comboBox_sort.SelectedIndex == 1)
                {
                    string query = $"select ИзбранныеРезюме.КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы] from ИзбранныеРезюме inner join Резюме on ИзбранныеРезюме.КодРезюме = Резюме.КодРезюме inner join Пользователи on Резюме.КодПользователя = Пользователи.КодПользователя where ИзбранныеРезюме.КодПользователя = '{userId}' order by Образование";
                    SqlCommand command = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                }
                else if (comboBox_sort.SelectedIndex == 2)
                {
                    string query = $"select ИзбранныеРезюме.КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы] from ИзбранныеРезюме inner join Резюме on ИзбранныеРезюме.КодРезюме = Резюме.КодРезюме inner join Пользователи on Резюме.КодПользователя = Пользователи.КодПользователя where ИзбранныеРезюме.КодПользователя = '{userId}' order by ГрафикРаботы";
                    SqlCommand command = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_filteredu_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string index = comboBox_filteredu.SelectedItem.ToString();
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select ИзбранныеРезюме.КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы] from ИзбранныеРезюме inner join Резюме on ИзбранныеРезюме.КодРезюме = Резюме.КодРезюме inner join Пользователи on Резюме.КодПользователя = Пользователи.КодПользователя where ИзбранныеРезюме.КодПользователя = '{userId}' and Образование = '{index}'";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_filtergraph_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string index = comboBox_filtergraph.SelectedItem.ToString();
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select ИзбранныеРезюме.КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы] from ИзбранныеРезюме inner join Резюме on ИзбранныеРезюме.КодРезюме = Резюме.КодРезюме inner join Пользователи on Резюме.КодПользователя = Пользователи.КодПользователя where ИзбранныеРезюме.КодПользователя = '{userId}' and ГрафикРаботы = '{index}'";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_delfromfav_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_delfromfav.BackColor = Color.Silver;
        }

        private void pictureBox_delfromfav_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_delfromfav.BackColor = Color.White;
        }
    }
}
