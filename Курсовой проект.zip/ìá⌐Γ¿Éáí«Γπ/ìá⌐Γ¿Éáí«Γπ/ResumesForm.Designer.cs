﻿namespace НайтиРаботу
{
    partial class ResumesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ОтображениеДанных = new System.Windows.Forms.DataGridView();
            this.button_otklik = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_sort = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox_filtergraph = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_filteredu = new System.Windows.Forms.ComboBox();
            this.toolTip_addfav = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox_addfav = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addfav)).BeginInit();
            this.SuspendLayout();
            // 
            // ОтображениеДанных
            // 
            this.ОтображениеДанных.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.ОтображениеДанных.BackgroundColor = System.Drawing.Color.White;
            this.ОтображениеДанных.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ОтображениеДанных.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ОтображениеДанных.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ОтображениеДанных.DefaultCellStyle = dataGridViewCellStyle2;
            this.ОтображениеДанных.Location = new System.Drawing.Point(12, 12);
            this.ОтображениеДанных.MultiSelect = false;
            this.ОтображениеДанных.Name = "ОтображениеДанных";
            this.ОтображениеДанных.ReadOnly = true;
            this.ОтображениеДанных.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ОтображениеДанных.Size = new System.Drawing.Size(892, 249);
            this.ОтображениеДанных.TabIndex = 2;
            this.ОтображениеДанных.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.ОтображениеДанных_CellMouseDoubleClick);
            // 
            // button_otklik
            // 
            this.button_otklik.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_otklik.FlatAppearance.BorderColor = System.Drawing.SystemColors.WindowFrame;
            this.button_otklik.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button_otklik.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_otklik.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_otklik.Location = new System.Drawing.Point(12, 276);
            this.button_otklik.Name = "button_otklik";
            this.button_otklik.Size = new System.Drawing.Size(210, 43);
            this.button_otklik.TabIndex = 30;
            this.button_otklik.Text = "Отправить приглашение";
            this.button_otklik.UseVisualStyleBackColor = true;
            this.button_otklik.Click += new System.EventHandler(this.button_otklik_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(450, 287);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 21);
            this.label1.TabIndex = 32;
            this.label1.Text = "Сортировать";
            // 
            // comboBox_sort
            // 
            this.comboBox_sort.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_sort.FormattingEnabled = true;
            this.comboBox_sort.Items.AddRange(new object[] {
            "По зарплате",
            "По образованию",
            "По графику работы"});
            this.comboBox_sort.Location = new System.Drawing.Point(566, 284);
            this.comboBox_sort.Name = "comboBox_sort";
            this.comboBox_sort.Size = new System.Drawing.Size(255, 29);
            this.comboBox_sort.TabIndex = 31;
            this.comboBox_sort.SelectedIndexChanged += new System.EventHandler(this.comboBox_sort_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(340, 396);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(214, 21);
            this.label3.TabIndex = 36;
            this.label3.Text = "Фильтр по графику работы";
            // 
            // comboBox_filtergraph
            // 
            this.comboBox_filtergraph.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_filtergraph.FormattingEnabled = true;
            this.comboBox_filtergraph.Items.AddRange(new object[] {
            "Полный рабочий день",
            "Сменный график",
            "Вахта",
            "Свободный график",
            "Удаленная работа",
            "Частичная занятость"});
            this.comboBox_filtergraph.Location = new System.Drawing.Point(566, 393);
            this.comboBox_filtergraph.Name = "comboBox_filtergraph";
            this.comboBox_filtergraph.Size = new System.Drawing.Size(255, 29);
            this.comboBox_filtergraph.TabIndex = 35;
            this.comboBox_filtergraph.SelectedIndexChanged += new System.EventHandler(this.comboBox_filtergraph_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(372, 342);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 21);
            this.label2.TabIndex = 38;
            this.label2.Text = "Фильтр по образованию";
            // 
            // comboBox_filteredu
            // 
            this.comboBox_filteredu.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_filteredu.FormattingEnabled = true;
            this.comboBox_filteredu.Items.AddRange(new object[] {
            "Среднее",
            "Среднее профессиональное",
            "Неполное высшее",
            "Высшее (бакалавр)",
            "Высшее (специалист)",
            "Высшее (магистр)",
            "Второе высшее",
            "Курсы переподготовки",
            "МВА",
            "Аспирантура",
            "Докторантура"});
            this.comboBox_filteredu.Location = new System.Drawing.Point(579, 339);
            this.comboBox_filteredu.Name = "comboBox_filteredu";
            this.comboBox_filteredu.Size = new System.Drawing.Size(242, 29);
            this.comboBox_filteredu.TabIndex = 37;
            this.comboBox_filteredu.SelectedIndexChanged += new System.EventHandler(this.comboBox_filteredu_SelectedIndexChanged);
            // 
            // pictureBox_addfav
            // 
            this.pictureBox_addfav.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_addfav.Image = global::НайтиРаботу.Properties.Resources.Add_Bookmark;
            this.pictureBox_addfav.Location = new System.Drawing.Point(12, 355);
            this.pictureBox_addfav.Name = "pictureBox_addfav";
            this.pictureBox_addfav.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_addfav.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_addfav.TabIndex = 29;
            this.pictureBox_addfav.TabStop = false;
            this.pictureBox_addfav.Click += new System.EventHandler(this.pictureBox_addfav_Click);
            this.pictureBox_addfav.MouseEnter += new System.EventHandler(this.pictureBox_addfav_MouseEnter);
            this.pictureBox_addfav.MouseLeave += new System.EventHandler(this.pictureBox_addfav_MouseLeave);
            // 
            // ResumesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(927, 521);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox_filteredu);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox_filtergraph);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_sort);
            this.Controls.Add(this.button_otklik);
            this.Controls.Add(this.pictureBox_addfav);
            this.Controls.Add(this.ОтображениеДанных);
            this.Name = "ResumesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ResumesForm";
            this.Load += new System.EventHandler(this.ResumesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addfav)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_otklik;
        private System.Windows.Forms.PictureBox pictureBox_addfav;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_sort;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox_filtergraph;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_filteredu;
        private System.Windows.Forms.ToolTip toolTip_addfav;
        public System.Windows.Forms.DataGridView ОтображениеДанных;
    }
}