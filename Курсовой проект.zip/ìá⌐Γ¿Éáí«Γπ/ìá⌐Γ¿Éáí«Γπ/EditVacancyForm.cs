﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace НайтиРаботу
{
    public partial class EditVacancyForm : Form
    {
        int userId = AuthForm.UserId;

        public EditVacancyForm()
        {
            InitializeComponent();
            toolTip_confirm.SetToolTip(pictureBox_confirm, "Подтвердить");
            toolTip_cancel.SetToolTip(pictureBox_cancel, "Закрыть");
        }

        private void pictureBox_confirm_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string newValue1 = textBox_spec.Text;
                    string newValue2 = textBox_city.Text;
                    string newValue4 = comboBox_exp.SelectedItem.ToString();
                    string newValue6 = comboBox_graph.SelectedItem.ToString();
                    string newValue7 = comboBox_otr.SelectedItem.ToString();
                    string newValue8 = textBox_sal.Text;
                    string newValue9 = comboBox_edu.SelectedItem.ToString();
                    string newValue10 = comboBox_status.SelectedItem.ToString();

                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    if (checkBox_stud.Checked == true)
                    {
                        string query = $"update Вакансии set Специализация = '{newValue1}', Город = '{newValue2}', Студентам = 'Да', ОпытРаботы = '{newValue4}', ГрафикРаботы = '{newValue6}', Отрасль = '{newValue7}', Зарплата = '{newValue8}', Образование = '{newValue9}', Статус = '{newValue10}' where КодВакансии = '{id}'; select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], Отрасль, Зарплата, Образование, ГрафикРаботы as [График работы], Статус from Вакансии where КодПользователя = '{userId}'";
                        SqlCommand com = new SqlCommand(query, con);
                        SqlDataAdapter adapter = new SqlDataAdapter(com);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        ОтображениеДанных.DataSource = dt;
                        MessageBox.Show("Вакансия обновлена", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (checkBox_stud.Checked == false)
                    {
                        string query = $"update Вакансии set Специализация = '{newValue1}', Город = '{newValue2}', Студентам = 'Нет', ОпытРаботы = '{newValue4}', ГрафикРаботы = '{newValue6}', Отрасль = '{newValue7}', Зарплата = '{newValue8}', Образование = '{newValue9}', Статус = '{newValue10}' where КодВакансии = '{id}'; select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [График работы], Отрасль, Зарплата, Образование, ГрафикРаботы as [График работы], Статус from Вакансии where КодПользователя = '{userId}'";
                        SqlCommand com = new SqlCommand(query, con);
                        SqlDataAdapter adapter = new SqlDataAdapter(com);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        ОтображениеДанных.DataSource = dt;
                        MessageBox.Show("Вакансия обновлена", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void pictureBox_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EditVacancyForm_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], Отрасль, Зарплата, Образование, ГрафикРаботы as [График работы], Статус from Вакансии where КодПользователя = '{userId}'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_cancel_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_cancel.BackColor = Color.Silver;
        }

        private void pictureBox_cancel_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_cancel.BackColor = Color.White;
        }

        private void pictureBox_confirm_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_confirm.BackColor = Color.Silver;
        }

        private void pictureBox_confirm_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_confirm.BackColor = Color.White;
        }

        private void ОтображениеДанных_SelectionChanged_1(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    label_id.Text = selectedRow.Cells["Номер"].Value.ToString();
                    textBox_spec.Text = selectedRow.Cells["Специализация"].Value.ToString();
                    textBox_city.Text = selectedRow.Cells["Город"].Value.ToString();
                    var cellValue = selectedRow.Cells["Студентам"].Value?.ToString();
                    if (cellValue == "Да")
                    {
                        checkBox_stud.Checked = true;
                    }
                    else if (cellValue == "Нет")
                    {
                        checkBox_stud.Checked = false;
                    }
                    comboBox_exp.SelectedItem = selectedRow.Cells["Опыт работы"].Value.ToString();
                    comboBox_graph.SelectedItem = selectedRow.Cells["График работы"].Value.ToString();
                    comboBox_otr.SelectedItem = selectedRow.Cells["Отрасль"].Value.ToString();
                    textBox_sal.Text = selectedRow.Cells["Зарплата"].Value.ToString();
                    comboBox_edu.SelectedItem = selectedRow.Cells["Образование"].Value.ToString();
                    comboBox_status.SelectedItem = selectedRow.Cells["Статус"].Value.ToString();

                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
