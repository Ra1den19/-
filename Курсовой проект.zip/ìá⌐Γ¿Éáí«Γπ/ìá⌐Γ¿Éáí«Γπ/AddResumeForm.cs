﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class AddResumeForm : Form
    {
        int userId = AuthForm.UserId;
        public AddResumeForm()
        {
            InitializeComponent();
            toolTip_add.SetToolTip(pictureBox_addresume, "Добавить");
            toolTip_cancel.SetToolTip(pictureBox_cancel, "Закрыть");
        }

        private void pictureBox_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox_addresume_Click(object sender, EventArgs e)
        {
            try
            {
                string grafik = comboBox_grafik.SelectedItem.ToString();
                string name = textBox_name.Text;
                string mail = textBox_mail.Text;
                string dol = textBox_dol.Text;
                string salary = textBox_sal.Text;
                string edu = comboBox_edu.SelectedItem.ToString();
                string navyk = nav.Text;

                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"insert into Резюме(КодПользователя, Наименование, ЖелаемаяДолжность, Зарплата, Образование, ЭлПочта, ГрафикРаботы, ПрофессиональныеНавыкиИЗнания) values('{userId}' ,'{name}', '{dol}', '{salary}', '{edu}', '{mail}', '{grafik}', '{navyk}'); select КодРезюме as Номер, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Резюме where КодПользователя = '{userId}'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                MessageBox.Show("Резюме успешно опубликовано", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox_name.Clear();
                textBox_mail.Clear();
                textBox_dol.Clear();
                textBox_sal.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_cancel_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_cancel.BackColor = Color.Silver;
        }

        private void pictureBox_cancel_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_cancel.BackColor = Color.White;
        }

        private void pictureBox_addresume_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_addresume.BackColor = Color.Silver;
        }

        private void pictureBox_addresume_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_addresume.BackColor = Color.White;
        }
    }
}
