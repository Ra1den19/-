﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class ClientForm : Form
    {
        public ClientForm()
        {
            InitializeComponent();
            toolTip_exit.SetToolTip(pictureBox_closeapp, "Закрыть программу");
            toolTip_logout.SetToolTip(pictureBox_logout, "Выйти из учетной записи");
        }

        private void percab_button_Click(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.FromArgb(0, 64, 0);
                favvacancies_button.BackColor = Color.Green;
                myotkliki_button.BackColor = Color.Green;
                vacancies_button.BackColor = Color.Green;
                PerCabForm pc = new PerCabForm();
                pc.TopLevel = false;
                pc.FormBorderStyle = FormBorderStyle.None;
                pc.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(pc);
                pc.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void vacancies_button_Click(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.Green;
                favvacancies_button.BackColor = Color.Green;
                myotkliki_button.BackColor = Color.Green;
                vacancies_button.BackColor = Color.FromArgb(0, 64, 0);
                VacanciesForm vf = new VacanciesForm();
                vf.TopLevel = false;
                vf.FormBorderStyle = FormBorderStyle.None;
                vf.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(vf);
                vf.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void myotkliki_button_Click(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.Green; ;
                favvacancies_button.BackColor = Color.Green;
                myotkliki_button.BackColor = Color.FromArgb(0, 64, 0);
                vacancies_button.BackColor = Color.Green;
                MyOtklikiForm of = new MyOtklikiForm();
                of.TopLevel = false;
                of.FormBorderStyle = FormBorderStyle.None;
                of.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(of);
                of.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void favvacancies_button_Click(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.Green;
                favvacancies_button.BackColor = Color.FromArgb(0, 64, 0);
                myotkliki_button.BackColor = Color.Green;
                vacancies_button.BackColor = Color.Green;
                FavVacanciesForm fv = new FavVacanciesForm();
                fv.TopLevel = false;
                fv.FormBorderStyle = FormBorderStyle.None;
                fv.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(fv);
                fv.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_closeapp_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Закрыть программу?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void pictureBox_logout_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Выйти из учетной записи?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void percab_button_MouseEnter(object sender, EventArgs e)
        {
            percab_button.ForeColor = Color.Red;
        }

        private void percab_button_MouseLeave(object sender, EventArgs e)
        {
            percab_button.ForeColor = Color.White;
        }

        private void favvacancies_button_MouseEnter(object sender, EventArgs e)
        {
            favvacancies_button.ForeColor = Color.Red;
        }

        private void favvacancies_button_MouseLeave(object sender, EventArgs e)
        {
            favvacancies_button.ForeColor = Color.White;
        }

        private void myotkliki_button_MouseEnter(object sender, EventArgs e)
        {
            myotkliki_button.ForeColor = Color.Red;
        }

        private void myotkliki_button_MouseLeave(object sender, EventArgs e)
        {
            myotkliki_button.ForeColor = Color.White;
        }

        private void vacancies_button_MouseEnter(object sender, EventArgs e)
        {
            vacancies_button.ForeColor = Color.Red;
        }

        private void vacancies_button_MouseLeave(object sender, EventArgs e)
        {
            vacancies_button.ForeColor = Color.White;
        }

        private void ClientForm_Load(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.FromArgb(0, 64, 0);
                favvacancies_button.BackColor = Color.Green;
                myotkliki_button.BackColor = Color.Green;
                vacancies_button.BackColor= Color.Green;
                PerCabForm pc = new PerCabForm();
                pc.TopLevel = false;
                pc.FormBorderStyle = FormBorderStyle.None;
                pc.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(pc);
                pc.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_closeapp_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_closeapp.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBox_closeapp_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_closeapp.BackColor = Color.Green;
        }

        private void pictureBox_logout_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_logout.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBox_logout_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_logout.BackColor = Color.Green;
        }
    }
}
