﻿namespace НайтиРаботу
{
    partial class AddVacancyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddVacancyForm));
            this.label_grafik = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label_edu = new System.Windows.Forms.Label();
            this.label_sal = new System.Windows.Forms.Label();
            this.label_dol = new System.Windows.Forms.Label();
            this.label_phone = new System.Windows.Forms.Label();
            this.label_mail = new System.Windows.Forms.Label();
            this.label_fio = new System.Windows.Forms.Label();
            this.textBox_spec = new System.Windows.Forms.TextBox();
            this.textBox_city = new System.Windows.Forms.TextBox();
            this.checkBox_stud = new System.Windows.Forms.CheckBox();
            this.comboBox_exp = new System.Windows.Forms.ComboBox();
            this.comboBox_graph = new System.Windows.Forms.ComboBox();
            this.comboBox_edu = new System.Windows.Forms.ComboBox();
            this.comboBox_otr = new System.Windows.Forms.ComboBox();
            this.textBox_sal = new System.Windows.Forms.TextBox();
            this.toolTip_add = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_cancel = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox_cancel = new System.Windows.Forms.PictureBox();
            this.pictureBox_addvacancy = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_cancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addvacancy)).BeginInit();
            this.SuspendLayout();
            // 
            // label_grafik
            // 
            this.label_grafik.AutoSize = true;
            this.label_grafik.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_grafik.Location = new System.Drawing.Point(46, 420);
            this.label_grafik.Name = "label_grafik";
            this.label_grafik.Size = new System.Drawing.Size(127, 17);
            this.label_grafik.TabIndex = 47;
            this.label_grafik.Text = "Отрасль компании";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_name.Location = new System.Drawing.Point(46, 6);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(105, 17);
            this.label_name.TabIndex = 46;
            this.label_name.Text = "Специализация";
            // 
            // label_edu
            // 
            this.label_edu.AutoSize = true;
            this.label_edu.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_edu.Location = new System.Drawing.Point(46, 358);
            this.label_edu.Name = "label_edu";
            this.label_edu.Size = new System.Drawing.Size(92, 17);
            this.label_edu.TabIndex = 45;
            this.label_edu.Text = "Образование";
            // 
            // label_sal
            // 
            this.label_sal.AutoSize = true;
            this.label_sal.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_sal.Location = new System.Drawing.Point(46, 296);
            this.label_sal.Name = "label_sal";
            this.label_sal.Size = new System.Drawing.Size(65, 17);
            this.label_sal.TabIndex = 44;
            this.label_sal.Text = "Зарплата";
            // 
            // label_dol
            // 
            this.label_dol.AutoSize = true;
            this.label_dol.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_dol.Location = new System.Drawing.Point(46, 231);
            this.label_dol.Name = "label_dol";
            this.label_dol.Size = new System.Drawing.Size(103, 17);
            this.label_dol.TabIndex = 43;
            this.label_dol.Text = "График работы";
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_phone.Location = new System.Drawing.Point(46, 173);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(93, 17);
            this.label_phone.TabIndex = 41;
            this.label_phone.Text = "Опыт работы";
            // 
            // label_mail
            // 
            this.label_mail.AutoSize = true;
            this.label_mail.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_mail.Location = new System.Drawing.Point(46, 125);
            this.label_mail.Name = "label_mail";
            this.label_mail.Size = new System.Drawing.Size(74, 17);
            this.label_mail.TabIndex = 40;
            this.label_mail.Text = "Студентам";
            // 
            // label_fio
            // 
            this.label_fio.AutoSize = true;
            this.label_fio.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_fio.Location = new System.Drawing.Point(46, 64);
            this.label_fio.Name = "label_fio";
            this.label_fio.Size = new System.Drawing.Size(45, 17);
            this.label_fio.TabIndex = 39;
            this.label_fio.Text = "Город";
            // 
            // textBox_spec
            // 
            this.textBox_spec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_spec.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_spec.Location = new System.Drawing.Point(49, 26);
            this.textBox_spec.Name = "textBox_spec";
            this.textBox_spec.Size = new System.Drawing.Size(470, 25);
            this.textBox_spec.TabIndex = 48;
            // 
            // textBox_city
            // 
            this.textBox_city.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_city.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_city.Location = new System.Drawing.Point(49, 84);
            this.textBox_city.Name = "textBox_city";
            this.textBox_city.Size = new System.Drawing.Size(470, 25);
            this.textBox_city.TabIndex = 49;
            // 
            // checkBox_stud
            // 
            this.checkBox_stud.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.checkBox_stud.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox_stud.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox_stud.Location = new System.Drawing.Point(49, 145);
            this.checkBox_stud.Name = "checkBox_stud";
            this.checkBox_stud.Size = new System.Drawing.Size(17, 16);
            this.checkBox_stud.TabIndex = 50;
            this.checkBox_stud.UseVisualStyleBackColor = true;
            // 
            // comboBox_exp
            // 
            this.comboBox_exp.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_exp.FormattingEnabled = true;
            this.comboBox_exp.Items.AddRange(new object[] {
            "Без опыта",
            "Менее года",
            "1-2 года",
            "3-4 года",
            "5-9 лет",
            "10 лет и более"});
            this.comboBox_exp.Location = new System.Drawing.Point(49, 193);
            this.comboBox_exp.Name = "comboBox_exp";
            this.comboBox_exp.Size = new System.Drawing.Size(470, 25);
            this.comboBox_exp.TabIndex = 51;
            // 
            // comboBox_graph
            // 
            this.comboBox_graph.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_graph.FormattingEnabled = true;
            this.comboBox_graph.Items.AddRange(new object[] {
            "Полный рабочий день",
            "Сменный график",
            "Вахта",
            "Свободный график",
            "Удаленная работа",
            "Частичная занятость"});
            this.comboBox_graph.Location = new System.Drawing.Point(49, 251);
            this.comboBox_graph.Name = "comboBox_graph";
            this.comboBox_graph.Size = new System.Drawing.Size(470, 25);
            this.comboBox_graph.TabIndex = 52;
            // 
            // comboBox_edu
            // 
            this.comboBox_edu.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_edu.FormattingEnabled = true;
            this.comboBox_edu.Items.AddRange(new object[] {
            "Среднее",
            "Среднее профессиональное",
            "Неполное высшее",
            "Высшее (бакалавр)",
            "Высшее (специалист)",
            "Высшее (магистр)",
            "Второе высшее",
            "Курсы переподготовки",
            "МВА",
            "Аспирантура",
            "Докторантура"});
            this.comboBox_edu.Location = new System.Drawing.Point(49, 378);
            this.comboBox_edu.Name = "comboBox_edu";
            this.comboBox_edu.Size = new System.Drawing.Size(470, 25);
            this.comboBox_edu.TabIndex = 53;
            // 
            // comboBox_otr
            // 
            this.comboBox_otr.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_otr.FormattingEnabled = true;
            this.comboBox_otr.Items.AddRange(new object[] {
            "Торговля",
            "HR / Кадры / Подбор персонала",
            "Производство / Агропром",
            "Логистика / Склад / ВЭД",
            "Строительство / ЖКХ / Эксплуатация",
            "IT / Интернет / Телеком",
            "Банки / Инвестиции / Ценные бумаги",
            "Рестораны / Питание",
            "Маркетинг / Реклама / PR",
            "Транспорт / Автобизнес / Автосервис",
            "Медицина / Фармация / Ветеринария",
            "Охрана / Безопасность",
            "Недвижимость / Риелторские услуги",
            "Образование / Наука",
            "Бытовые услуги / Обслуживание оборудования",
            "СМИ / Издательства",
            "Туризм / Гостиницы",
            "Консалтинг / Тренинги",
            "Госслужба / Некоммерческие организации",
            "Красота / Фитнес / Спорт",
            "Дизайн / Полиграфия",
            "Юриспруденция",
            "Культура / Искусство / Развлечения",
            "Страхование"});
            this.comboBox_otr.Location = new System.Drawing.Point(49, 440);
            this.comboBox_otr.Name = "comboBox_otr";
            this.comboBox_otr.Size = new System.Drawing.Size(470, 25);
            this.comboBox_otr.TabIndex = 54;
            // 
            // textBox_sal
            // 
            this.textBox_sal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_sal.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_sal.Location = new System.Drawing.Point(49, 316);
            this.textBox_sal.Name = "textBox_sal";
            this.textBox_sal.Size = new System.Drawing.Size(470, 25);
            this.textBox_sal.TabIndex = 55;
            // 
            // pictureBox_cancel
            // 
            this.pictureBox_cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_cancel.Image = global::НайтиРаботу.Properties.Resources.Canceladd;
            this.pictureBox_cancel.Location = new System.Drawing.Point(570, 489);
            this.pictureBox_cancel.Name = "pictureBox_cancel";
            this.pictureBox_cancel.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_cancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_cancel.TabIndex = 58;
            this.pictureBox_cancel.TabStop = false;
            this.pictureBox_cancel.Click += new System.EventHandler(this.pictureBox_cancel_Click);
            this.pictureBox_cancel.MouseEnter += new System.EventHandler(this.pictureBox_cancel_MouseEnter);
            this.pictureBox_cancel.MouseLeave += new System.EventHandler(this.pictureBox_cancel_MouseLeave);
            // 
            // pictureBox_addvacancy
            // 
            this.pictureBox_addvacancy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_addvacancy.Image = global::НайтиРаботу.Properties.Resources.apply;
            this.pictureBox_addvacancy.Location = new System.Drawing.Point(660, 489);
            this.pictureBox_addvacancy.Name = "pictureBox_addvacancy";
            this.pictureBox_addvacancy.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_addvacancy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_addvacancy.TabIndex = 57;
            this.pictureBox_addvacancy.TabStop = false;
            this.pictureBox_addvacancy.Click += new System.EventHandler(this.pictureBox_addvacancy_Click);
            this.pictureBox_addvacancy.MouseEnter += new System.EventHandler(this.pictureBox_addvacancy_MouseEnter);
            this.pictureBox_addvacancy.MouseLeave += new System.EventHandler(this.pictureBox_addvacancy_MouseLeave);
            // 
            // AddVacancyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(724, 486);
            this.Controls.Add(this.pictureBox_cancel);
            this.Controls.Add(this.pictureBox_addvacancy);
            this.Controls.Add(this.textBox_sal);
            this.Controls.Add(this.comboBox_otr);
            this.Controls.Add(this.comboBox_edu);
            this.Controls.Add(this.comboBox_graph);
            this.Controls.Add(this.comboBox_exp);
            this.Controls.Add(this.checkBox_stud);
            this.Controls.Add(this.textBox_city);
            this.Controls.Add(this.textBox_spec);
            this.Controls.Add(this.label_grafik);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.label_edu);
            this.Controls.Add(this.label_sal);
            this.Controls.Add(this.label_dol);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.label_mail);
            this.Controls.Add(this.label_fio);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddVacancyForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.AddVacancyForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_cancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addvacancy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolTip toolTip_add;
        private System.Windows.Forms.ToolTip toolTip_cancel;
        public System.Windows.Forms.Label label_grafik;
        public System.Windows.Forms.Label label_name;
        public System.Windows.Forms.Label label_edu;
        public System.Windows.Forms.Label label_sal;
        public System.Windows.Forms.Label label_dol;
        public System.Windows.Forms.Label label_phone;
        public System.Windows.Forms.Label label_mail;
        public System.Windows.Forms.Label label_fio;
        public System.Windows.Forms.TextBox textBox_spec;
        public System.Windows.Forms.TextBox textBox_city;
        public System.Windows.Forms.CheckBox checkBox_stud;
        public System.Windows.Forms.ComboBox comboBox_exp;
        public System.Windows.Forms.ComboBox comboBox_graph;
        public System.Windows.Forms.ComboBox comboBox_edu;
        public System.Windows.Forms.ComboBox comboBox_otr;
        public System.Windows.Forms.TextBox textBox_sal;
        public System.Windows.Forms.PictureBox pictureBox_cancel;
        public System.Windows.Forms.PictureBox pictureBox_addvacancy;
    }
}