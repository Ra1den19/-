﻿namespace НайтиРаботу
{
    partial class RegForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_date = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.label_role = new System.Windows.Forms.Label();
            this.comboBox_role = new System.Windows.Forms.ComboBox();
            this.label_ot = new System.Windows.Forms.Label();
            this.textBox_ot = new System.Windows.Forms.TextBox();
            this.label_im = new System.Windows.Forms.Label();
            this.textBox_im = new System.Windows.Forms.TextBox();
            this.label_fam = new System.Windows.Forms.Label();
            this.textBox_fam = new System.Windows.Forms.TextBox();
            this.label_password = new System.Windows.Forms.Label();
            this.label_login = new System.Windows.Forms.Label();
            this.button_reg = new System.Windows.Forms.Button();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.textBox_login = new System.Windows.Forms.TextBox();
            this.label_nom = new System.Windows.Forms.Label();
            this.maskedTextBox_nom = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // label_date
            // 
            this.label_date.AutoSize = true;
            this.label_date.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_date.Location = new System.Drawing.Point(15, 213);
            this.label_date.Name = "label_date";
            this.label_date.Size = new System.Drawing.Size(128, 21);
            this.label_date.TabIndex = 39;
            this.label_date.Text = "Дата рождения";
            // 
            // date
            // 
            this.date.CalendarFont = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.date.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.date.Location = new System.Drawing.Point(18, 238);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(268, 29);
            this.date.TabIndex = 38;
            // 
            // label_role
            // 
            this.label_role.AutoSize = true;
            this.label_role.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_role.Location = new System.Drawing.Point(15, 524);
            this.label_role.Name = "label_role";
            this.label_role.Size = new System.Drawing.Size(194, 21);
            this.label_role.TabIndex = 37;
            this.label_role.Text = "Зарегистрироваться как";
            // 
            // comboBox_role
            // 
            this.comboBox_role.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_role.FormattingEnabled = true;
            this.comboBox_role.Items.AddRange(new object[] {
            "Соискатель",
            "Работодатель"});
            this.comboBox_role.Location = new System.Drawing.Point(19, 549);
            this.comboBox_role.Name = "comboBox_role";
            this.comboBox_role.Size = new System.Drawing.Size(267, 29);
            this.comboBox_role.TabIndex = 36;
            // 
            // label_ot
            // 
            this.label_ot.AutoSize = true;
            this.label_ot.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_ot.Location = new System.Drawing.Point(15, 141);
            this.label_ot.Name = "label_ot";
            this.label_ot.Size = new System.Drawing.Size(123, 21);
            this.label_ot.TabIndex = 35;
            this.label_ot.Text = "Ваше отчество";
            // 
            // textBox_ot
            // 
            this.textBox_ot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_ot.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_ot.Location = new System.Drawing.Point(18, 166);
            this.textBox_ot.Name = "textBox_ot";
            this.textBox_ot.Size = new System.Drawing.Size(268, 29);
            this.textBox_ot.TabIndex = 34;
            // 
            // label_im
            // 
            this.label_im.AutoSize = true;
            this.label_im.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_im.Location = new System.Drawing.Point(14, 74);
            this.label_im.Name = "label_im";
            this.label_im.Size = new System.Drawing.Size(85, 21);
            this.label_im.TabIndex = 33;
            this.label_im.Text = "Ваше имя";
            // 
            // textBox_im
            // 
            this.textBox_im.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_im.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_im.Location = new System.Drawing.Point(18, 99);
            this.textBox_im.Name = "textBox_im";
            this.textBox_im.Size = new System.Drawing.Size(268, 29);
            this.textBox_im.TabIndex = 32;
            // 
            // label_fam
            // 
            this.label_fam.AutoSize = true;
            this.label_fam.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_fam.Location = new System.Drawing.Point(14, 9);
            this.label_fam.Name = "label_fam";
            this.label_fam.Size = new System.Drawing.Size(123, 21);
            this.label_fam.TabIndex = 31;
            this.label_fam.Text = "Ваша фамилия";
            // 
            // textBox_fam
            // 
            this.textBox_fam.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_fam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_fam.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_fam.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox_fam.Location = new System.Drawing.Point(18, 34);
            this.textBox_fam.Name = "textBox_fam";
            this.textBox_fam.Size = new System.Drawing.Size(268, 29);
            this.textBox_fam.TabIndex = 30;
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_password.Location = new System.Drawing.Point(16, 449);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(163, 21);
            this.label_password.TabIndex = 29;
            this.label_password.Text = "Придумайте пароль";
            // 
            // label_login
            // 
            this.label_login.AutoSize = true;
            this.label_login.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_login.Location = new System.Drawing.Point(15, 368);
            this.label_login.Name = "label_login";
            this.label_login.Size = new System.Drawing.Size(153, 21);
            this.label_login.TabIndex = 28;
            this.label_login.Text = "Придумайте логин";
            // 
            // button_reg
            // 
            this.button_reg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_reg.FlatAppearance.BorderColor = System.Drawing.SystemColors.WindowFrame;
            this.button_reg.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button_reg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reg.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_reg.Location = new System.Drawing.Point(19, 606);
            this.button_reg.Name = "button_reg";
            this.button_reg.Size = new System.Drawing.Size(267, 43);
            this.button_reg.TabIndex = 27;
            this.button_reg.Text = "Зарегистрироваться";
            this.button_reg.UseVisualStyleBackColor = true;
            this.button_reg.Click += new System.EventHandler(this.button_reg_Click);
            // 
            // textBox_password
            // 
            this.textBox_password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_password.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_password.Location = new System.Drawing.Point(18, 474);
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.Size = new System.Drawing.Size(268, 29);
            this.textBox_password.TabIndex = 26;
            // 
            // textBox_login
            // 
            this.textBox_login.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_login.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_login.Location = new System.Drawing.Point(18, 393);
            this.textBox_login.Name = "textBox_login";
            this.textBox_login.Size = new System.Drawing.Size(268, 29);
            this.textBox_login.TabIndex = 25;
            // 
            // label_nom
            // 
            this.label_nom.AutoSize = true;
            this.label_nom.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_nom.Location = new System.Drawing.Point(15, 295);
            this.label_nom.Name = "label_nom";
            this.label_nom.Size = new System.Drawing.Size(172, 21);
            this.label_nom.TabIndex = 47;
            this.label_nom.Text = "Ваш номер телефона";
            // 
            // maskedTextBox_nom
            // 
            this.maskedTextBox_nom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.maskedTextBox_nom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.maskedTextBox_nom.Location = new System.Drawing.Point(18, 319);
            this.maskedTextBox_nom.Mask = "+7(999) 000-00-00";
            this.maskedTextBox_nom.Name = "maskedTextBox_nom";
            this.maskedTextBox_nom.Size = new System.Drawing.Size(268, 26);
            this.maskedTextBox_nom.TabIndex = 48;
            // 
            // RegForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(400, 661);
            this.Controls.Add(this.maskedTextBox_nom);
            this.Controls.Add(this.label_nom);
            this.Controls.Add(this.label_date);
            this.Controls.Add(this.date);
            this.Controls.Add(this.label_role);
            this.Controls.Add(this.comboBox_role);
            this.Controls.Add(this.label_ot);
            this.Controls.Add(this.textBox_ot);
            this.Controls.Add(this.label_im);
            this.Controls.Add(this.textBox_im);
            this.Controls.Add(this.label_fam);
            this.Controls.Add(this.textBox_fam);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.label_login);
            this.Controls.Add(this.button_reg);
            this.Controls.Add(this.textBox_password);
            this.Controls.Add(this.textBox_login);
            this.Name = "RegForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_date;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.Label label_role;
        private System.Windows.Forms.ComboBox comboBox_role;
        private System.Windows.Forms.Label label_ot;
        private System.Windows.Forms.TextBox textBox_ot;
        private System.Windows.Forms.Label label_im;
        private System.Windows.Forms.TextBox textBox_im;
        private System.Windows.Forms.Label label_fam;
        private System.Windows.Forms.TextBox textBox_fam;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.Label label_login;
        private System.Windows.Forms.Button button_reg;
        private System.Windows.Forms.TextBox textBox_password;
        private System.Windows.Forms.TextBox textBox_login;
        private System.Windows.Forms.Label label_nom;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_nom;
    }
}