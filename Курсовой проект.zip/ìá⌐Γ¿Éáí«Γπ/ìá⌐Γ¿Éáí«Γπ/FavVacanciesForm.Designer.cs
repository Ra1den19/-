﻿namespace НайтиРаботу
{
    partial class FavVacanciesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ОтображениеДанных = new System.Windows.Forms.DataGridView();
            this.comboBox_sort = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_filter = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox_filtergraph = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox_filterotrasli = new System.Windows.Forms.ComboBox();
            this.button_otklik = new System.Windows.Forms.Button();
            this.checkBox_stud = new System.Windows.Forms.CheckBox();
            this.toolTip_delfav = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox_delfromfav = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_delfromfav)).BeginInit();
            this.SuspendLayout();
            // 
            // ОтображениеДанных
            // 
            this.ОтображениеДанных.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.ОтображениеДанных.BackgroundColor = System.Drawing.Color.White;
            this.ОтображениеДанных.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ОтображениеДанных.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ОтображениеДанных.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ОтображениеДанных.DefaultCellStyle = dataGridViewCellStyle2;
            this.ОтображениеДанных.Location = new System.Drawing.Point(12, 12);
            this.ОтображениеДанных.MultiSelect = false;
            this.ОтображениеДанных.Name = "ОтображениеДанных";
            this.ОтображениеДанных.ReadOnly = true;
            this.ОтображениеДанных.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ОтображениеДанных.Size = new System.Drawing.Size(909, 249);
            this.ОтображениеДанных.TabIndex = 0;
            // 
            // comboBox_sort
            // 
            this.comboBox_sort.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_sort.FormattingEnabled = true;
            this.comboBox_sort.Items.AddRange(new object[] {
            "По зарплате",
            "По опыту работы",
            "По графику работы",
            "По отрасли"});
            this.comboBox_sort.Location = new System.Drawing.Point(532, 279);
            this.comboBox_sort.Name = "comboBox_sort";
            this.comboBox_sort.Size = new System.Drawing.Size(255, 29);
            this.comboBox_sort.TabIndex = 1;
            this.comboBox_sort.SelectedIndexChanged += new System.EventHandler(this.comboBox_sort_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(416, 279);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 21);
            this.label1.TabIndex = 2;
            this.label1.Text = "Сортировать";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(394, 325);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "Фильтр по опыту работы";
            // 
            // comboBox_filter
            // 
            this.comboBox_filter.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_filter.FormattingEnabled = true;
            this.comboBox_filter.Items.AddRange(new object[] {
            "Без опыта",
            "Менее года",
            "1-2 года",
            "3-4 года",
            "5-9 лет",
            "10 лет и более"});
            this.comboBox_filter.Location = new System.Drawing.Point(601, 322);
            this.comboBox_filter.Name = "comboBox_filter";
            this.comboBox_filter.Size = new System.Drawing.Size(186, 29);
            this.comboBox_filter.TabIndex = 3;
            this.comboBox_filter.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(306, 367);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(214, 21);
            this.label3.TabIndex = 6;
            this.label3.Text = "Фильтр по графику работы";
            // 
            // comboBox_filtergraph
            // 
            this.comboBox_filtergraph.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_filtergraph.FormattingEnabled = true;
            this.comboBox_filtergraph.Items.AddRange(new object[] {
            "Полный рабочий день",
            "Сменный график",
            "Вахта",
            "Свободный график",
            "Удаленная работа",
            "Частичная занятость"});
            this.comboBox_filtergraph.Location = new System.Drawing.Point(532, 364);
            this.comboBox_filtergraph.Name = "comboBox_filtergraph";
            this.comboBox_filtergraph.Size = new System.Drawing.Size(255, 29);
            this.comboBox_filtergraph.TabIndex = 5;
            this.comboBox_filtergraph.SelectedIndexChanged += new System.EventHandler(this.comboBox_filtergraph_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(367, 408);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 21);
            this.label4.TabIndex = 8;
            this.label4.Text = "Фильтр по отрасли";
            // 
            // comboBox_filterotrasli
            // 
            this.comboBox_filterotrasli.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_filterotrasli.FormattingEnabled = true;
            this.comboBox_filterotrasli.Items.AddRange(new object[] {
            "Торговля",
            "HR / Кадры / Подбор персонала",
            "Производство / Агропром",
            "Логистика / Склад / ВЭД",
            "Строительство / ЖКХ / Эксплуатация",
            "IT / Интернет / Телеком",
            "Банки / Инвестиции / Ценные бумаги",
            "Рестораны / Питание",
            "Маркетинг / Реклама / PR",
            "Транспорт / Автобизнес / Автосервис",
            "Медицина / Фармация / Ветеринария",
            "Охрана / Безопасность",
            "Недвижимость / Риелторские услуги",
            "Образование / Наука",
            "Бытовые услуги / Обслуживание оборудования",
            "СМИ / Издательства",
            "Туризм / Гостиницы",
            "Консалтинг / Тренинги",
            "Госслужба / Некоммерческие организации",
            "Красота / Фитнес / Спорт",
            "Дизайн / Полиграфия",
            "Юриспруденция",
            "Культура / Искусство / Развлечения",
            "Страхование"});
            this.comboBox_filterotrasli.Location = new System.Drawing.Point(532, 405);
            this.comboBox_filterotrasli.Name = "comboBox_filterotrasli";
            this.comboBox_filterotrasli.Size = new System.Drawing.Size(389, 29);
            this.comboBox_filterotrasli.TabIndex = 7;
            this.comboBox_filterotrasli.SelectedIndexChanged += new System.EventHandler(this.comboBox_filterotrasli_SelectedIndexChanged);
            // 
            // button_otklik
            // 
            this.button_otklik.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_otklik.FlatAppearance.BorderColor = System.Drawing.SystemColors.WindowFrame;
            this.button_otklik.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button_otklik.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_otklik.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_otklik.Location = new System.Drawing.Point(12, 272);
            this.button_otklik.Name = "button_otklik";
            this.button_otklik.Size = new System.Drawing.Size(186, 43);
            this.button_otklik.TabIndex = 29;
            this.button_otklik.Text = "Откликнуться";
            this.button_otklik.UseVisualStyleBackColor = true;
            this.button_otklik.Click += new System.EventHandler(this.button_otklik_Click);
            // 
            // checkBox_stud
            // 
            this.checkBox_stud.AutoSize = true;
            this.checkBox_stud.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.checkBox_stud.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox_stud.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox_stud.Location = new System.Drawing.Point(532, 439);
            this.checkBox_stud.Name = "checkBox_stud";
            this.checkBox_stud.Size = new System.Drawing.Size(104, 25);
            this.checkBox_stud.TabIndex = 38;
            this.checkBox_stud.Text = "Студентам";
            this.checkBox_stud.UseVisualStyleBackColor = true;
            this.checkBox_stud.CheckedChanged += new System.EventHandler(this.checkBox_stud_CheckedChanged);
            // 
            // pictureBox_delfromfav
            // 
            this.pictureBox_delfromfav.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_delfromfav.Image = global::НайтиРаботу.Properties.Resources.Remove_Bookmark;
            this.pictureBox_delfromfav.Location = new System.Drawing.Point(12, 347);
            this.pictureBox_delfromfav.Name = "pictureBox_delfromfav";
            this.pictureBox_delfromfav.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_delfromfav.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_delfromfav.TabIndex = 18;
            this.pictureBox_delfromfav.TabStop = false;
            this.pictureBox_delfromfav.Click += new System.EventHandler(this.pictureBox_delfromfav_Click);
            this.pictureBox_delfromfav.MouseEnter += new System.EventHandler(this.pictureBox_delfromfav_MouseEnter);
            this.pictureBox_delfromfav.MouseLeave += new System.EventHandler(this.pictureBox_delfromfav_MouseLeave);
            // 
            // FavVacanciesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(954, 508);
            this.Controls.Add(this.checkBox_stud);
            this.Controls.Add(this.button_otklik);
            this.Controls.Add(this.pictureBox_delfromfav);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox_filterotrasli);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox_filtergraph);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox_filter);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_sort);
            this.Controls.Add(this.ОтображениеДанных);
            this.Name = "FavVacanciesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FavVacanciesForm";
            this.Load += new System.EventHandler(this.FavVacanciesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_delfromfav)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ОтображениеДанных;
        private System.Windows.Forms.ComboBox comboBox_sort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_filter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox_filtergraph;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox_filterotrasli;
        private System.Windows.Forms.PictureBox pictureBox_delfromfav;
        private System.Windows.Forms.Button button_otklik;
        private System.Windows.Forms.CheckBox checkBox_stud;
        private System.Windows.Forms.ToolTip toolTip_delfav;
    }
}