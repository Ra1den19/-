﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        private void button_reg_Click(object sender, EventArgs e)
        {
            try
            {
                string fam = textBox_fam.Text;
                string im = textBox_im.Text;
                string ot = textBox_ot.Text;
                string Date = date.Value.ToShortDateString();
                string nom = maskedTextBox_nom.Text;
                string login = textBox_login.Text;
                string password = textBox_password.Text;
                string role = comboBox_role.SelectedItem.ToString();

                if (textBox_fam.Text != "" && textBox_im.Text != "" && maskedTextBox_nom.Text != "" && textBox_login.Text != "" && textBox_password.Text != "")
                {
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    string query = $"insert into Пользователи(Логин, Пароль, Роль, Фамилия, Имя, Отчество, ДатаРождения, НомерТелефона) values('{login}', '{password}', '{role}', '{fam}', '{im}', '{ot}', '{Date}', '{nom}')";
                    con.Open();
                    SqlCommand com = new SqlCommand(query, con);
                    com.ExecuteNonQuery();
                    DialogResult res = MessageBox.Show("Вы успешно зарегистрированы", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    DialogResult res = MessageBox.Show("Пожалуйста, заполните необходимые поля", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex) 
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
