﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class FavVacanciesForm : Form
    {
        int userId = AuthForm.UserId;
        public FavVacanciesForm()
        {
            InitializeComponent();
            toolTip_delfav.SetToolTip(pictureBox_delfromfav, "Убрать из избранного");
        }

        private void FavVacanciesForm_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_filterotrasli_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string otrasl = comboBox_filterotrasli.SelectedItem.ToString();
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}' and Отрасль = '{otrasl}'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_delfromfav_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"delete from ИзбранныеВакансии where КодВакансии = '{id}'; select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}'";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Вакансия удалена из избранных", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_otklik_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"insert into Отклики(КодПользователя, КодВакансии) values('{userId}', '{id}'); select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}'";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Вы успешно откликнулись на вакансию", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_sort_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            if (comboBox_sort.SelectedIndex == 0)
            {
                string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}' order by Зарплата";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            else if (comboBox_sort.SelectedIndex == 1)
            {
                string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}' order by ОпытРаботы";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            else if (comboBox_sort.SelectedIndex == 2)
            {
                string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}' order by ГрафикРаботы";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            else if (comboBox_sort.SelectedIndex == 3)
            {
                string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}' order by Отрасль";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
        }

        private void comboBox_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string index = comboBox_filter.SelectedItem.ToString();
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}' and ОпытРаботы = '{index}'";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            ОтображениеДанных.DataSource = dt;
        }

        private void comboBox_filtergraph_SelectedIndexChanged(object sender, EventArgs e)
        {
            string index = comboBox_filtergraph.SelectedItem.ToString();
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}' and ГрафикРаботы = '{index}'";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            ОтображениеДанных.DataSource = dt;
        }

        private void checkBox_stud_CheckedChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            if (checkBox_stud.Checked == true)
            {
                string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}' and Студентам = 'Да'";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            else
            {
                string query = $"select ИзбранныеВакансии.КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии inner join ИзбранныеВакансии on Вакансии.КодВакансии = ИзбранныеВакансии.КодВакансии where ИзбранныеВакансии.КодПользователя = '{userId}'";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
        }

        private void pictureBox_delfromfav_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_delfromfav.BackColor = Color.Silver;
        }

        private void pictureBox_delfromfav_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_delfromfav.BackColor = Color.White;
        }
    }
}
