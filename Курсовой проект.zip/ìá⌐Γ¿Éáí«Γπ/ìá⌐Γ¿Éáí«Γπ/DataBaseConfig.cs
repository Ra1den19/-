﻿using System;
using System.Collections.Generic;
using System.Data.Sql;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace НайтиРаботу
{
    public static class DataBaseConfig
    {
        public static string ConnectionString { get; private set; }

        static DataBaseConfig()
        {
            string serverName = Environment.MachineName + @"\SQLEXPRESS";
            string databaseName = "НайтиРаботу";
            ConnectionString = $@"Data Source={serverName};Initial Catalog={databaseName};Integrated Security=True";
        }
    }
}
