﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace НайтиРаботу
{
    public partial class AuthForm : Form
    {
        public static int UserId;
        public AuthForm()
        {
            InitializeComponent();
        }

        private void auth_button_Click(object sender, EventArgs e)
        {
            try
            {
                string login = textBox_login.Text;
                string password = textBox_password.Text;
                if(textBox_login.Text != "" && textBox_password.Text != "")
                {
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    string query = $"select * from Пользователи where Логин = '{login}' and Пароль = '{password}'";
                    SqlCommand com = new SqlCommand(query, con);
                    con.Open();
                    SqlDataReader rd = com.ExecuteReader();
                    if (rd.HasRows) 
                    {
                        while (rd.Read()) 
                        {
                            UserId = (int)rd["КодПользователя"];
                            string role = rd["Роль"].ToString();
                            if (role == "Соискатель")
                            {
                                ClientForm cf = new ClientForm();
                                cf.ShowDialog();
                                textBox_login.Clear();
                                textBox_password.Clear();
                            }
                            else if (role == "Работодатель")
                            { 
                                RabotodatelForm rf = new RabotodatelForm();
                                rf.ShowDialog();
                                textBox_login.Clear();
                                textBox_password.Clear();
                            }
                        }
                    }
                    else
                    {
                        DialogResult res = MessageBox.Show("Неверный логин или пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    DialogResult res = MessageBox.Show("Поля для заполнения пусты!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex) 
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void checkBoxPas_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBoxPas.Checked == true)
            {
                textBox_password.UseSystemPasswordChar = false;
                checkBoxPas.Text = "Скрыть пароль";
            }
            else if(checkBoxPas.Checked == false)
            {
                textBox_password.UseSystemPasswordChar = true;
                checkBoxPas.Text = "Показать пароль";
            }
        }
    }
}
