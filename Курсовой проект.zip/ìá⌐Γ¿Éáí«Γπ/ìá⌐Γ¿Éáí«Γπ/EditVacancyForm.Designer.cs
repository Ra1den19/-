﻿namespace НайтиРаботу
{
    partial class EditVacancyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditVacancyForm));
            this.ОтображениеДанных = new System.Windows.Forms.DataGridView();
            this.label_name = new System.Windows.Forms.Label();
            this.textBox_spec = new System.Windows.Forms.TextBox();
            this.label_city = new System.Windows.Forms.Label();
            this.textBox_city = new System.Windows.Forms.TextBox();
            this.checkBox_stud = new System.Windows.Forms.CheckBox();
            this.label_stud = new System.Windows.Forms.Label();
            this.comboBox_exp = new System.Windows.Forms.ComboBox();
            this.label_exp = new System.Windows.Forms.Label();
            this.comboBox_graph = new System.Windows.Forms.ComboBox();
            this.label_graph = new System.Windows.Forms.Label();
            this.comboBox_otr = new System.Windows.Forms.ComboBox();
            this.label_otr = new System.Windows.Forms.Label();
            this.label_sal = new System.Windows.Forms.Label();
            this.textBox_sal = new System.Windows.Forms.TextBox();
            this.comboBox_edu = new System.Windows.Forms.ComboBox();
            this.label_edu = new System.Windows.Forms.Label();
            this.label_id = new System.Windows.Forms.Label();
            this.toolTip_confirm = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_cancel = new System.Windows.Forms.ToolTip(this.components);
            this.label_status = new System.Windows.Forms.Label();
            this.comboBox_status = new System.Windows.Forms.ComboBox();
            this.pictureBox_cancel = new System.Windows.Forms.PictureBox();
            this.pictureBox_confirm = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_cancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_confirm)).BeginInit();
            this.SuspendLayout();
            // 
            // ОтображениеДанных
            // 
            this.ОтображениеДанных.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.ОтображениеДанных.BackgroundColor = System.Drawing.Color.White;
            this.ОтображениеДанных.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ОтображениеДанных.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ОтображениеДанных.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ОтображениеДанных.DefaultCellStyle = dataGridViewCellStyle2;
            this.ОтображениеДанных.Location = new System.Drawing.Point(12, 12);
            this.ОтображениеДанных.MultiSelect = false;
            this.ОтображениеДанных.Name = "ОтображениеДанных";
            this.ОтображениеДанных.ReadOnly = true;
            this.ОтображениеДанных.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ОтображениеДанных.Size = new System.Drawing.Size(930, 256);
            this.ОтображениеДанных.TabIndex = 18;
            this.ОтображениеДанных.SelectionChanged += new System.EventHandler(this.ОтображениеДанных_SelectionChanged_1);
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_name.Location = new System.Drawing.Point(57, 276);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(105, 17);
            this.label_name.TabIndex = 37;
            this.label_name.Text = "Специализация";
            // 
            // textBox_spec
            // 
            this.textBox_spec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_spec.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_spec.Location = new System.Drawing.Point(60, 296);
            this.textBox_spec.Name = "textBox_spec";
            this.textBox_spec.Size = new System.Drawing.Size(470, 25);
            this.textBox_spec.TabIndex = 36;
            // 
            // label_city
            // 
            this.label_city.AutoSize = true;
            this.label_city.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_city.Location = new System.Drawing.Point(57, 331);
            this.label_city.Name = "label_city";
            this.label_city.Size = new System.Drawing.Size(45, 17);
            this.label_city.TabIndex = 39;
            this.label_city.Text = "Город";
            // 
            // textBox_city
            // 
            this.textBox_city.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_city.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_city.Location = new System.Drawing.Point(60, 351);
            this.textBox_city.Name = "textBox_city";
            this.textBox_city.Size = new System.Drawing.Size(470, 25);
            this.textBox_city.TabIndex = 38;
            // 
            // checkBox_stud
            // 
            this.checkBox_stud.AutoSize = true;
            this.checkBox_stud.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox_stud.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox_stud.Location = new System.Drawing.Point(60, 408);
            this.checkBox_stud.Name = "checkBox_stud";
            this.checkBox_stud.Size = new System.Drawing.Size(12, 11);
            this.checkBox_stud.TabIndex = 40;
            this.checkBox_stud.UseVisualStyleBackColor = true;
            // 
            // label_stud
            // 
            this.label_stud.AutoSize = true;
            this.label_stud.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_stud.Location = new System.Drawing.Point(57, 388);
            this.label_stud.Name = "label_stud";
            this.label_stud.Size = new System.Drawing.Size(74, 17);
            this.label_stud.TabIndex = 41;
            this.label_stud.Text = "Студентам";
            // 
            // comboBox_exp
            // 
            this.comboBox_exp.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_exp.FormattingEnabled = true;
            this.comboBox_exp.Items.AddRange(new object[] {
            "Без опыта",
            "Менее года",
            "1-2 года",
            "3-4 года",
            "5-9 лет",
            "10 лет и более"});
            this.comboBox_exp.Location = new System.Drawing.Point(60, 447);
            this.comboBox_exp.Name = "comboBox_exp";
            this.comboBox_exp.Size = new System.Drawing.Size(470, 25);
            this.comboBox_exp.TabIndex = 43;
            // 
            // label_exp
            // 
            this.label_exp.AutoSize = true;
            this.label_exp.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_exp.Location = new System.Drawing.Point(57, 427);
            this.label_exp.Name = "label_exp";
            this.label_exp.Size = new System.Drawing.Size(93, 17);
            this.label_exp.TabIndex = 42;
            this.label_exp.Text = "Опыт работы";
            // 
            // comboBox_graph
            // 
            this.comboBox_graph.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_graph.FormattingEnabled = true;
            this.comboBox_graph.Items.AddRange(new object[] {
            "Полный рабочий день",
            "Сменный график",
            "Вахта",
            "Свободный график",
            "Удаленная работа",
            "Частичная занятость"});
            this.comboBox_graph.Location = new System.Drawing.Point(60, 500);
            this.comboBox_graph.Name = "comboBox_graph";
            this.comboBox_graph.Size = new System.Drawing.Size(470, 25);
            this.comboBox_graph.TabIndex = 47;
            // 
            // label_graph
            // 
            this.label_graph.AutoSize = true;
            this.label_graph.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_graph.Location = new System.Drawing.Point(57, 480);
            this.label_graph.Name = "label_graph";
            this.label_graph.Size = new System.Drawing.Size(103, 17);
            this.label_graph.TabIndex = 46;
            this.label_graph.Text = "График работы";
            // 
            // comboBox_otr
            // 
            this.comboBox_otr.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_otr.FormattingEnabled = true;
            this.comboBox_otr.Items.AddRange(new object[] {
            "Торговля",
            "HR / Кадры / Подбор персонала",
            "Производство / Агропром",
            "Логистика / Склад / ВЭД",
            "Строительство / ЖКХ / Эксплуатация",
            "IT / Интернет / Телеком",
            "Банки / Инвестиции / Ценные бумаги",
            "Рестораны / Питание",
            "Маркетинг / Реклама / PR",
            "Транспорт / Автобизнес / Автосервис",
            "Медицина / Фармация / Ветеринария",
            "Охрана / Безопасность",
            "Недвижимость / Риелторские услуги",
            "Образование / Наука",
            "Бытовые услуги / Обслуживание оборудования",
            "СМИ / Издательства",
            "Туризм / Гостиницы",
            "Консалтинг / Тренинги",
            "Госслужба / Некоммерческие организации",
            "Красота / Фитнес / Спорт",
            "Дизайн / Полиграфия",
            "Юриспруденция",
            "Культура / Искусство / Развлечения",
            "Страхование"});
            this.comboBox_otr.Location = new System.Drawing.Point(60, 555);
            this.comboBox_otr.Name = "comboBox_otr";
            this.comboBox_otr.Size = new System.Drawing.Size(470, 25);
            this.comboBox_otr.TabIndex = 49;
            // 
            // label_otr
            // 
            this.label_otr.AutoSize = true;
            this.label_otr.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_otr.Location = new System.Drawing.Point(57, 535);
            this.label_otr.Name = "label_otr";
            this.label_otr.Size = new System.Drawing.Size(59, 17);
            this.label_otr.TabIndex = 48;
            this.label_otr.Text = "Отрасль";
            // 
            // label_sal
            // 
            this.label_sal.AutoSize = true;
            this.label_sal.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_sal.Location = new System.Drawing.Point(57, 588);
            this.label_sal.Name = "label_sal";
            this.label_sal.Size = new System.Drawing.Size(65, 17);
            this.label_sal.TabIndex = 51;
            this.label_sal.Text = "Зарплата";
            // 
            // textBox_sal
            // 
            this.textBox_sal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_sal.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_sal.Location = new System.Drawing.Point(60, 608);
            this.textBox_sal.Name = "textBox_sal";
            this.textBox_sal.Size = new System.Drawing.Size(470, 25);
            this.textBox_sal.TabIndex = 50;
            // 
            // comboBox_edu
            // 
            this.comboBox_edu.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_edu.FormattingEnabled = true;
            this.comboBox_edu.Items.AddRange(new object[] {
            "Среднее",
            "Среднее профессиональное",
            "Неполное высшее",
            "Высшее (бакалавр)",
            "Высшее (специалист)",
            "Высшее (магистр)",
            "Второе высшее",
            "Курсы переподготовки",
            "МВА",
            "Аспирантура",
            "Докторантура"});
            this.comboBox_edu.Location = new System.Drawing.Point(60, 661);
            this.comboBox_edu.Name = "comboBox_edu";
            this.comboBox_edu.Size = new System.Drawing.Size(470, 25);
            this.comboBox_edu.TabIndex = 53;
            // 
            // label_edu
            // 
            this.label_edu.AutoSize = true;
            this.label_edu.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_edu.Location = new System.Drawing.Point(57, 641);
            this.label_edu.Name = "label_edu";
            this.label_edu.Size = new System.Drawing.Size(92, 17);
            this.label_edu.TabIndex = 52;
            this.label_edu.Text = "Образование";
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Location = new System.Drawing.Point(940, 271);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(0, 13);
            this.label_id.TabIndex = 56;
            this.label_id.Visible = false;
            // 
            // label_status
            // 
            this.label_status.AutoSize = true;
            this.label_status.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_status.Location = new System.Drawing.Point(57, 694);
            this.label_status.Name = "label_status";
            this.label_status.Size = new System.Drawing.Size(48, 17);
            this.label_status.TabIndex = 58;
            this.label_status.Text = "Статус";
            // 
            // comboBox_status
            // 
            this.comboBox_status.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_status.FormattingEnabled = true;
            this.comboBox_status.Items.AddRange(new object[] {
            "Открыта",
            "Закрыта"});
            this.comboBox_status.Location = new System.Drawing.Point(60, 714);
            this.comboBox_status.Name = "comboBox_status";
            this.comboBox_status.Size = new System.Drawing.Size(470, 25);
            this.comboBox_status.TabIndex = 59;
            // 
            // pictureBox_cancel
            // 
            this.pictureBox_cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_cancel.Image = global::НайтиРаботу.Properties.Resources.Canceladd;
            this.pictureBox_cancel.Location = new System.Drawing.Point(811, 808);
            this.pictureBox_cancel.Name = "pictureBox_cancel";
            this.pictureBox_cancel.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_cancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_cancel.TabIndex = 55;
            this.pictureBox_cancel.TabStop = false;
            this.pictureBox_cancel.Click += new System.EventHandler(this.pictureBox_cancel_Click);
            this.pictureBox_cancel.MouseEnter += new System.EventHandler(this.pictureBox_cancel_MouseEnter);
            this.pictureBox_cancel.MouseLeave += new System.EventHandler(this.pictureBox_cancel_MouseLeave);
            // 
            // pictureBox_confirm
            // 
            this.pictureBox_confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_confirm.Image = global::НайтиРаботу.Properties.Resources.apply;
            this.pictureBox_confirm.Location = new System.Drawing.Point(905, 806);
            this.pictureBox_confirm.Name = "pictureBox_confirm";
            this.pictureBox_confirm.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_confirm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_confirm.TabIndex = 54;
            this.pictureBox_confirm.TabStop = false;
            this.pictureBox_confirm.Click += new System.EventHandler(this.pictureBox_confirm_Click);
            this.pictureBox_confirm.MouseEnter += new System.EventHandler(this.pictureBox_confirm_MouseEnter);
            this.pictureBox_confirm.MouseLeave += new System.EventHandler(this.pictureBox_confirm_MouseLeave);
            // 
            // EditVacancyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(986, 537);
            this.Controls.Add(this.comboBox_status);
            this.Controls.Add(this.label_status);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.pictureBox_cancel);
            this.Controls.Add(this.pictureBox_confirm);
            this.Controls.Add(this.comboBox_edu);
            this.Controls.Add(this.label_edu);
            this.Controls.Add(this.label_sal);
            this.Controls.Add(this.textBox_sal);
            this.Controls.Add(this.comboBox_otr);
            this.Controls.Add(this.label_otr);
            this.Controls.Add(this.comboBox_graph);
            this.Controls.Add(this.label_graph);
            this.Controls.Add(this.comboBox_exp);
            this.Controls.Add(this.label_exp);
            this.Controls.Add(this.label_stud);
            this.Controls.Add(this.checkBox_stud);
            this.Controls.Add(this.label_city);
            this.Controls.Add(this.textBox_city);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.textBox_spec);
            this.Controls.Add(this.ОтображениеДанных);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditVacancyForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.EditVacancyForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_cancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_confirm)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ОтображениеДанных;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_city;
        private System.Windows.Forms.CheckBox checkBox_stud;
        private System.Windows.Forms.Label label_stud;
        private System.Windows.Forms.Label label_exp;
        private System.Windows.Forms.Label label_graph;
        private System.Windows.Forms.Label label_otr;
        private System.Windows.Forms.Label label_sal;
        private System.Windows.Forms.Label label_edu;
        private System.Windows.Forms.PictureBox pictureBox_cancel;
        private System.Windows.Forms.PictureBox pictureBox_confirm;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.ToolTip toolTip_confirm;
        private System.Windows.Forms.ToolTip toolTip_cancel;
        private System.Windows.Forms.Label label_status;
        public System.Windows.Forms.TextBox textBox_spec;
        public System.Windows.Forms.TextBox textBox_city;
        public System.Windows.Forms.ComboBox comboBox_exp;
        public System.Windows.Forms.ComboBox comboBox_graph;
        public System.Windows.Forms.ComboBox comboBox_otr;
        public System.Windows.Forms.TextBox textBox_sal;
        public System.Windows.Forms.ComboBox comboBox_edu;
        public System.Windows.Forms.ComboBox comboBox_status;
    }
}