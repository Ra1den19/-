﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class PerCabForm : Form
    {
        int userId = AuthForm.UserId;
        public PerCabForm()
        {
            InitializeComponent();
            toolTip_add.SetToolTip(pictureBox_addresume, "Добавить");
            toolTip_edit.SetToolTip(pictureBox_editresume, "Изменить");
            toolTip_del.SetToolTip(pictureBox_deleteresume, "Удалить");
        }

        private void pictureBox_addresume_Click(object sender, EventArgs e)
        {
            AddResumeForm ar = new AddResumeForm();
            ar.ShowDialog();
        }

        private void pictureBox_editresume_Click(object sender, EventArgs e)
        {
            EditResumeForm er = new EditResumeForm();
            er.ShowDialog();
        }

        private void PerCabForm_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select КодРезюме as Номер, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Резюме where КодПользователя = '{userId}'";
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_deleteresume_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"delete from Резюме where КодРезюме = '{id}'; select КодРезюме as Номер, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Резюме where КодПользователя = '{userId}'";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Резюме удалено", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_addresume_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_addresume.BackColor = Color.Silver;
        }

        private void pictureBox_addresume_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_addresume.BackColor = Color.White;
        }

        private void pictureBox_editresume_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_editresume.BackColor = Color.Silver;
        }

        private void pictureBox_editresume_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_editresume.BackColor = Color.White;
        }

        private void pictureBox_deleteresume_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_deleteresume.BackColor = Color.Silver;
        }

        private void pictureBox_deleteresume_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_deleteresume.BackColor = Color.White;
        }
    }
}
