﻿namespace НайтиРаботу
{
    partial class PerCabForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ОтображениеДанных = new System.Windows.Forms.DataGridView();
            this.toolTip_add = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_edit = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_del = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox_deleteresume = new System.Windows.Forms.PictureBox();
            this.pictureBox_editresume = new System.Windows.Forms.PictureBox();
            this.pictureBox_addresume = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_deleteresume)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_editresume)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addresume)).BeginInit();
            this.SuspendLayout();
            // 
            // ОтображениеДанных
            // 
            this.ОтображениеДанных.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.ОтображениеДанных.BackgroundColor = System.Drawing.Color.White;
            this.ОтображениеДанных.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ОтображениеДанных.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.ОтображениеДанных.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ОтображениеДанных.DefaultCellStyle = dataGridViewCellStyle4;
            this.ОтображениеДанных.Location = new System.Drawing.Point(12, 12);
            this.ОтображениеДанных.MultiSelect = false;
            this.ОтображениеДанных.Name = "ОтображениеДанных";
            this.ОтображениеДанных.ReadOnly = true;
            this.ОтображениеДанных.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ОтображениеДанных.Size = new System.Drawing.Size(914, 347);
            this.ОтображениеДанных.TabIndex = 0;
            // 
            // pictureBox_deleteresume
            // 
            this.pictureBox_deleteresume.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_deleteresume.Image = global::НайтиРаботу.Properties.Resources.Trash;
            this.pictureBox_deleteresume.Location = new System.Drawing.Point(145, 374);
            this.pictureBox_deleteresume.Name = "pictureBox_deleteresume";
            this.pictureBox_deleteresume.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_deleteresume.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_deleteresume.TabIndex = 3;
            this.pictureBox_deleteresume.TabStop = false;
            this.pictureBox_deleteresume.Click += new System.EventHandler(this.pictureBox_deleteresume_Click);
            this.pictureBox_deleteresume.MouseEnter += new System.EventHandler(this.pictureBox_deleteresume_MouseEnter);
            this.pictureBox_deleteresume.MouseLeave += new System.EventHandler(this.pictureBox_deleteresume_MouseLeave);
            // 
            // pictureBox_editresume
            // 
            this.pictureBox_editresume.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_editresume.Image = global::НайтиРаботу.Properties.Resources.Edit;
            this.pictureBox_editresume.Location = new System.Drawing.Point(77, 374);
            this.pictureBox_editresume.Name = "pictureBox_editresume";
            this.pictureBox_editresume.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_editresume.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_editresume.TabIndex = 2;
            this.pictureBox_editresume.TabStop = false;
            this.pictureBox_editresume.Click += new System.EventHandler(this.pictureBox_editresume_Click);
            this.pictureBox_editresume.MouseEnter += new System.EventHandler(this.pictureBox_editresume_MouseEnter);
            this.pictureBox_editresume.MouseLeave += new System.EventHandler(this.pictureBox_editresume_MouseLeave);
            // 
            // pictureBox_addresume
            // 
            this.pictureBox_addresume.BackColor = System.Drawing.Color.White;
            this.pictureBox_addresume.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_addresume.Image = global::НайтиРаботу.Properties.Resources.Add_New;
            this.pictureBox_addresume.Location = new System.Drawing.Point(12, 374);
            this.pictureBox_addresume.Name = "pictureBox_addresume";
            this.pictureBox_addresume.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_addresume.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_addresume.TabIndex = 1;
            this.pictureBox_addresume.TabStop = false;
            this.pictureBox_addresume.Click += new System.EventHandler(this.pictureBox_addresume_Click);
            this.pictureBox_addresume.MouseEnter += new System.EventHandler(this.pictureBox_addresume_MouseEnter);
            this.pictureBox_addresume.MouseLeave += new System.EventHandler(this.pictureBox_addresume_MouseLeave);
            // 
            // PerCabForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(954, 454);
            this.Controls.Add(this.pictureBox_deleteresume);
            this.Controls.Add(this.pictureBox_editresume);
            this.Controls.Add(this.pictureBox_addresume);
            this.Controls.Add(this.ОтображениеДанных);
            this.Name = "PerCabForm";
            this.Text = "PerCabForm";
            this.Load += new System.EventHandler(this.PerCabForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_deleteresume)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_editresume)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addresume)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView ОтображениеДанных;
        private System.Windows.Forms.PictureBox pictureBox_addresume;
        private System.Windows.Forms.PictureBox pictureBox_editresume;
        private System.Windows.Forms.PictureBox pictureBox_deleteresume;
        private System.Windows.Forms.ToolTip toolTip_add;
        private System.Windows.Forms.ToolTip toolTip_edit;
        private System.Windows.Forms.ToolTip toolTip_del;
    }
}