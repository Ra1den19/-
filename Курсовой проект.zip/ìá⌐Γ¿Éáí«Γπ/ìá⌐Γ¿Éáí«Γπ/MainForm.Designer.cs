﻿namespace НайтиРаботу
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.exit_button = new System.Windows.Forms.Button();
            this.reg_button = new System.Windows.Forms.Button();
            this.auth_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label_version = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(185, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(328, 450);
            this.panel1.TabIndex = 8;
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.Green;
            this.exit_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exit_button.FlatAppearance.BorderSize = 0;
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.ForeColor = System.Drawing.Color.White;
            this.exit_button.Image = global::НайтиРаботу.Properties.Resources.close;
            this.exit_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.exit_button.Location = new System.Drawing.Point(0, 386);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(185, 40);
            this.exit_button.TabIndex = 7;
            this.exit_button.Text = "выход";
            this.exit_button.UseVisualStyleBackColor = false;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            this.exit_button.MouseEnter += new System.EventHandler(this.exit_button_MouseEnter);
            this.exit_button.MouseLeave += new System.EventHandler(this.exit_button_MouseLeave);
            // 
            // reg_button
            // 
            this.reg_button.BackColor = System.Drawing.Color.Green;
            this.reg_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.reg_button.FlatAppearance.BorderSize = 0;
            this.reg_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.reg_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.reg_button.ForeColor = System.Drawing.Color.White;
            this.reg_button.Image = global::НайтиРаботу.Properties.Resources.reg;
            this.reg_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.reg_button.Location = new System.Drawing.Point(0, 87);
            this.reg_button.Name = "reg_button";
            this.reg_button.Size = new System.Drawing.Size(185, 40);
            this.reg_button.TabIndex = 6;
            this.reg_button.Text = "регистрация";
            this.reg_button.UseVisualStyleBackColor = false;
            this.reg_button.Click += new System.EventHandler(this.reg_button_Click);
            this.reg_button.MouseEnter += new System.EventHandler(this.reg_button_MouseEnter);
            this.reg_button.MouseLeave += new System.EventHandler(this.reg_button_MouseLeave);
            // 
            // auth_button
            // 
            this.auth_button.BackColor = System.Drawing.Color.Green;
            this.auth_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.auth_button.FlatAppearance.BorderSize = 0;
            this.auth_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.auth_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.auth_button.ForeColor = System.Drawing.Color.White;
            this.auth_button.Image = global::НайтиРаботу.Properties.Resources.auth;
            this.auth_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.auth_button.Location = new System.Drawing.Point(0, 28);
            this.auth_button.Name = "auth_button";
            this.auth_button.Size = new System.Drawing.Size(185, 40);
            this.auth_button.TabIndex = 5;
            this.auth_button.Text = "вход";
            this.auth_button.UseVisualStyleBackColor = false;
            this.auth_button.Click += new System.EventHandler(this.auth_button_Click);
            this.auth_button.MouseEnter += new System.EventHandler(this.auth_button_MouseEnter);
            this.auth_button.MouseLeave += new System.EventHandler(this.auth_button_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Green;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(185, 462);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label_version
            // 
            this.label_version.AutoSize = true;
            this.label_version.BackColor = System.Drawing.Color.Green;
            this.label_version.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_version.Location = new System.Drawing.Point(1, 446);
            this.label_version.Name = "label_version";
            this.label_version.Size = new System.Drawing.Size(39, 13);
            this.label_version.TabIndex = 9;
            this.label_version.Text = "Ver 1.0";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(513, 462);
            this.Controls.Add(this.label_version);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.reg_button);
            this.Controls.Add(this.auth_button);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(529, 501);
            this.MinimumSize = new System.Drawing.Size(529, 501);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Найти Работу";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button auth_button;
        private System.Windows.Forms.Button reg_button;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_version;
    }
}

