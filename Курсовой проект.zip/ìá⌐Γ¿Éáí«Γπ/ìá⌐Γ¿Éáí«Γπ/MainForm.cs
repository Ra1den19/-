﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Закрыть программу?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void auth_button_Click(object sender, EventArgs e)
        {
            try
            {
                auth_button.BackColor = Color.FromArgb(0, 64, 0);
                reg_button.BackColor = Color.Green;
                AuthForm au = new AuthForm();
                au.TopLevel = false;
                au.FormBorderStyle = FormBorderStyle.None;
                au.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(au);
                au.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void reg_button_Click(object sender, EventArgs e)
        {
            try
            {
                reg_button.BackColor = Color.FromArgb(0, 64, 0);
                auth_button.BackColor = Color.Green;
                RegForm reg = new RegForm();
                reg.TopLevel = false;
                reg.FormBorderStyle = FormBorderStyle.None;
                reg.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(reg);
                reg.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                auth_button.BackColor = Color.FromArgb(0, 64, 0);
                reg_button.BackColor = Color.Green;
                AuthForm au = new AuthForm();
                au.TopLevel = false;
                au.FormBorderStyle = FormBorderStyle.None;
                au.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(au);
                au.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void auth_button_MouseEnter(object sender, EventArgs e)
        {
            auth_button.ForeColor = Color.Red;
        }

        private void auth_button_MouseLeave(object sender, EventArgs e)
        {
            auth_button.ForeColor = Color.White;
        }

        private void reg_button_MouseEnter(object sender, EventArgs e)
        {
            reg_button.ForeColor = Color.Red;
        }

        private void reg_button_MouseLeave(object sender, EventArgs e)
        {
            reg_button.ForeColor = Color.White;
        }

        private void exit_button_MouseEnter(object sender, EventArgs e)
        {
            exit_button.ForeColor = Color.Red;
        }

        private void exit_button_MouseLeave(object sender, EventArgs e)
        {
            exit_button.ForeColor = Color.White;
        }
    }
}
