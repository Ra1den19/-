﻿namespace НайтиРаботу
{
    partial class ClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClientForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolTip_exit = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_logout = new System.Windows.Forms.ToolTip(this.components);
            this.label_version = new System.Windows.Forms.Label();
            this.pictureBox_logout = new System.Windows.Forms.PictureBox();
            this.pictureBox_closeapp = new System.Windows.Forms.PictureBox();
            this.vacancies_button = new System.Windows.Forms.Button();
            this.myotkliki_button = new System.Windows.Forms.Button();
            this.favvacancies_button = new System.Windows.Forms.Button();
            this.percab_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_logout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_closeapp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(212, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(943, 492);
            this.panel1.TabIndex = 14;
            // 
            // label_version
            // 
            this.label_version.AutoSize = true;
            this.label_version.BackColor = System.Drawing.Color.Green;
            this.label_version.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_version.Location = new System.Drawing.Point(1, 488);
            this.label_version.Name = "label_version";
            this.label_version.Size = new System.Drawing.Size(39, 13);
            this.label_version.TabIndex = 24;
            this.label_version.Text = "Ver 1.0";
            // 
            // pictureBox_logout
            // 
            this.pictureBox_logout.BackColor = System.Drawing.Color.Green;
            this.pictureBox_logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_logout.Image = global::НайтиРаботу.Properties.Resources.Open_Door;
            this.pictureBox_logout.Location = new System.Drawing.Point(166, 431);
            this.pictureBox_logout.Name = "pictureBox_logout";
            this.pictureBox_logout.Size = new System.Drawing.Size(40, 40);
            this.pictureBox_logout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_logout.TabIndex = 20;
            this.pictureBox_logout.TabStop = false;
            this.pictureBox_logout.Click += new System.EventHandler(this.pictureBox_logout_Click);
            this.pictureBox_logout.MouseEnter += new System.EventHandler(this.pictureBox_logout_MouseEnter);
            this.pictureBox_logout.MouseLeave += new System.EventHandler(this.pictureBox_logout_MouseLeave);
            // 
            // pictureBox_closeapp
            // 
            this.pictureBox_closeapp.BackColor = System.Drawing.Color.Green;
            this.pictureBox_closeapp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_closeapp.Image = global::НайтиРаботу.Properties.Resources.Shutdown;
            this.pictureBox_closeapp.Location = new System.Drawing.Point(6, 431);
            this.pictureBox_closeapp.Name = "pictureBox_closeapp";
            this.pictureBox_closeapp.Size = new System.Drawing.Size(40, 40);
            this.pictureBox_closeapp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_closeapp.TabIndex = 19;
            this.pictureBox_closeapp.TabStop = false;
            this.pictureBox_closeapp.Click += new System.EventHandler(this.pictureBox_closeapp_Click);
            this.pictureBox_closeapp.MouseEnter += new System.EventHandler(this.pictureBox_closeapp_MouseEnter);
            this.pictureBox_closeapp.MouseLeave += new System.EventHandler(this.pictureBox_closeapp_MouseLeave);
            // 
            // vacancies_button
            // 
            this.vacancies_button.BackColor = System.Drawing.Color.Green;
            this.vacancies_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vacancies_button.FlatAppearance.BorderSize = 0;
            this.vacancies_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vacancies_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.vacancies_button.ForeColor = System.Drawing.Color.White;
            this.vacancies_button.Image = global::НайтиРаботу.Properties.Resources.vacancies;
            this.vacancies_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.vacancies_button.Location = new System.Drawing.Point(0, 249);
            this.vacancies_button.Name = "vacancies_button";
            this.vacancies_button.Size = new System.Drawing.Size(212, 40);
            this.vacancies_button.TabIndex = 17;
            this.vacancies_button.Text = "вакансии";
            this.vacancies_button.UseVisualStyleBackColor = false;
            this.vacancies_button.Click += new System.EventHandler(this.vacancies_button_Click);
            this.vacancies_button.MouseEnter += new System.EventHandler(this.vacancies_button_MouseEnter);
            this.vacancies_button.MouseLeave += new System.EventHandler(this.vacancies_button_MouseLeave);
            // 
            // myotkliki_button
            // 
            this.myotkliki_button.BackColor = System.Drawing.Color.Green;
            this.myotkliki_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myotkliki_button.FlatAppearance.BorderSize = 0;
            this.myotkliki_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myotkliki_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.myotkliki_button.ForeColor = System.Drawing.Color.White;
            this.myotkliki_button.Image = global::НайтиРаботу.Properties.Resources.Done;
            this.myotkliki_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.myotkliki_button.Location = new System.Drawing.Point(0, 177);
            this.myotkliki_button.Name = "myotkliki_button";
            this.myotkliki_button.Size = new System.Drawing.Size(212, 40);
            this.myotkliki_button.TabIndex = 16;
            this.myotkliki_button.Text = "мои отклики";
            this.myotkliki_button.UseVisualStyleBackColor = false;
            this.myotkliki_button.Click += new System.EventHandler(this.myotkliki_button_Click);
            this.myotkliki_button.MouseEnter += new System.EventHandler(this.myotkliki_button_MouseEnter);
            this.myotkliki_button.MouseLeave += new System.EventHandler(this.myotkliki_button_MouseLeave);
            // 
            // favvacancies_button
            // 
            this.favvacancies_button.BackColor = System.Drawing.Color.Green;
            this.favvacancies_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.favvacancies_button.FlatAppearance.BorderSize = 0;
            this.favvacancies_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.favvacancies_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.favvacancies_button.ForeColor = System.Drawing.Color.White;
            this.favvacancies_button.Image = global::НайтиРаботу.Properties.Resources.Favorite;
            this.favvacancies_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.favvacancies_button.Location = new System.Drawing.Point(0, 98);
            this.favvacancies_button.Name = "favvacancies_button";
            this.favvacancies_button.Size = new System.Drawing.Size(212, 55);
            this.favvacancies_button.TabIndex = 15;
            this.favvacancies_button.Text = "      избранные вакансии";
            this.favvacancies_button.UseVisualStyleBackColor = false;
            this.favvacancies_button.Click += new System.EventHandler(this.favvacancies_button_Click);
            this.favvacancies_button.MouseEnter += new System.EventHandler(this.favvacancies_button_MouseEnter);
            this.favvacancies_button.MouseLeave += new System.EventHandler(this.favvacancies_button_MouseLeave);
            // 
            // percab_button
            // 
            this.percab_button.BackColor = System.Drawing.Color.Green;
            this.percab_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.percab_button.FlatAppearance.BorderSize = 0;
            this.percab_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.percab_button.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.percab_button.ForeColor = System.Drawing.Color.White;
            this.percab_button.Image = global::НайтиРаботу.Properties.Resources.Man;
            this.percab_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.percab_button.Location = new System.Drawing.Point(0, 33);
            this.percab_button.Name = "percab_button";
            this.percab_button.Size = new System.Drawing.Size(212, 40);
            this.percab_button.TabIndex = 13;
            this.percab_button.Text = "личный кабинет";
            this.percab_button.UseVisualStyleBackColor = false;
            this.percab_button.Click += new System.EventHandler(this.percab_button_Click);
            this.percab_button.MouseEnter += new System.EventHandler(this.percab_button_MouseEnter);
            this.percab_button.MouseLeave += new System.EventHandler(this.percab_button_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Green;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(212, 504);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // ClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1155, 504);
            this.Controls.Add(this.label_version);
            this.Controls.Add(this.pictureBox_logout);
            this.Controls.Add(this.pictureBox_closeapp);
            this.Controls.Add(this.vacancies_button);
            this.Controls.Add(this.myotkliki_button);
            this.Controls.Add(this.favvacancies_button);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.percab_button);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1171, 543);
            this.MinimumSize = new System.Drawing.Size(1171, 543);
            this.Name = "ClientForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Найти Работу";
            this.Load += new System.EventHandler(this.ClientForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_logout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_closeapp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button percab_button;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button favvacancies_button;
        private System.Windows.Forms.Button myotkliki_button;
        private System.Windows.Forms.Button vacancies_button;
        private System.Windows.Forms.PictureBox pictureBox_closeapp;
        private System.Windows.Forms.PictureBox pictureBox_logout;
        private System.Windows.Forms.ToolTip toolTip_exit;
        private System.Windows.Forms.ToolTip toolTip_logout;
        private System.Windows.Forms.Label label_version;
    }
}