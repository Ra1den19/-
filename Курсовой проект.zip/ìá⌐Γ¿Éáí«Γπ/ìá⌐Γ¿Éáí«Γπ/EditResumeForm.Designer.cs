﻿namespace НайтиРаботу
{
    partial class EditResumeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditResumeForm));
            this.comboBox_edu = new System.Windows.Forms.ComboBox();
            this.label_edu = new System.Windows.Forms.Label();
            this.label_sal = new System.Windows.Forms.Label();
            this.textBox_sal = new System.Windows.Forms.TextBox();
            this.label_dol = new System.Windows.Forms.Label();
            this.textBox_dol = new System.Windows.Forms.TextBox();
            this.label_mail = new System.Windows.Forms.Label();
            this.textBox_mail = new System.Windows.Forms.TextBox();
            this.ОтображениеДанных = new System.Windows.Forms.DataGridView();
            this.label_name = new System.Windows.Forms.Label();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.label_id = new System.Windows.Forms.Label();
            this.comboBox_grafik = new System.Windows.Forms.ComboBox();
            this.label_grafik = new System.Windows.Forms.Label();
            this.toolTip_confirm = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_cancelorclose = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox_cancel = new System.Windows.Forms.PictureBox();
            this.pictureBox_confirm = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nav = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_cancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_confirm)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox_edu
            // 
            this.comboBox_edu.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_edu.FormattingEnabled = true;
            this.comboBox_edu.Items.AddRange(new object[] {
            "Среднее",
            "Среднее профессиональное",
            "Неполное высшее",
            "Высшее (бакалавр)",
            "Высшее (специалист)",
            "Высшее (магистр)",
            "Второе высшее",
            "Курсы переподготовки",
            "МВА",
            "Аспирантура",
            "Докторантура"});
            this.comboBox_edu.Location = new System.Drawing.Point(238, 537);
            this.comboBox_edu.Name = "comboBox_edu";
            this.comboBox_edu.Size = new System.Drawing.Size(470, 29);
            this.comboBox_edu.TabIndex = 31;
            // 
            // label_edu
            // 
            this.label_edu.AutoSize = true;
            this.label_edu.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_edu.Location = new System.Drawing.Point(44, 540);
            this.label_edu.Name = "label_edu";
            this.label_edu.Size = new System.Drawing.Size(111, 21);
            this.label_edu.TabIndex = 30;
            this.label_edu.Text = "Образование";
            // 
            // label_sal
            // 
            this.label_sal.AutoSize = true;
            this.label_sal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_sal.Location = new System.Drawing.Point(44, 478);
            this.label_sal.Name = "label_sal";
            this.label_sal.Size = new System.Drawing.Size(78, 21);
            this.label_sal.TabIndex = 28;
            this.label_sal.Text = "Зарплата";
            // 
            // textBox_sal
            // 
            this.textBox_sal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_sal.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_sal.Location = new System.Drawing.Point(238, 475);
            this.textBox_sal.Name = "textBox_sal";
            this.textBox_sal.Size = new System.Drawing.Size(470, 29);
            this.textBox_sal.TabIndex = 27;
            // 
            // label_dol
            // 
            this.label_dol.AutoSize = true;
            this.label_dol.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_dol.Location = new System.Drawing.Point(44, 413);
            this.label_dol.Name = "label_dol";
            this.label_dol.Size = new System.Drawing.Size(176, 21);
            this.label_dol.TabIndex = 26;
            this.label_dol.Text = "Желаемая должность";
            // 
            // textBox_dol
            // 
            this.textBox_dol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_dol.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_dol.Location = new System.Drawing.Point(238, 410);
            this.textBox_dol.Name = "textBox_dol";
            this.textBox_dol.Size = new System.Drawing.Size(470, 29);
            this.textBox_dol.TabIndex = 25;
            // 
            // label_mail
            // 
            this.label_mail.AutoSize = true;
            this.label_mail.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_mail.Location = new System.Drawing.Point(44, 350);
            this.label_mail.Name = "label_mail";
            this.label_mail.Size = new System.Drawing.Size(80, 21);
            this.label_mail.TabIndex = 21;
            this.label_mail.Text = "Эл. почта";
            // 
            // textBox_mail
            // 
            this.textBox_mail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_mail.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_mail.Location = new System.Drawing.Point(238, 347);
            this.textBox_mail.Name = "textBox_mail";
            this.textBox_mail.Size = new System.Drawing.Size(470, 29);
            this.textBox_mail.TabIndex = 20;
            // 
            // ОтображениеДанных
            // 
            this.ОтображениеДанных.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.ОтображениеДанных.BackgroundColor = System.Drawing.Color.White;
            this.ОтображениеДанных.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ОтображениеДанных.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ОтображениеДанных.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ОтображениеДанных.DefaultCellStyle = dataGridViewCellStyle2;
            this.ОтображениеДанных.Location = new System.Drawing.Point(12, 12);
            this.ОтображениеДанных.MultiSelect = false;
            this.ОтображениеДанных.Name = "ОтображениеДанных";
            this.ОтображениеДанных.ReadOnly = true;
            this.ОтображениеДанных.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ОтображениеДанных.Size = new System.Drawing.Size(930, 252);
            this.ОтображениеДанных.TabIndex = 17;
            this.ОтображениеДанных.SelectionChanged += new System.EventHandler(this.ОтображениеДанных_SelectionChanged);
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_name.Location = new System.Drawing.Point(44, 288);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(147, 21);
            this.label_name.TabIndex = 35;
            this.label_name.Text = "Название резюме";
            // 
            // textBox_name
            // 
            this.textBox_name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_name.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_name.Location = new System.Drawing.Point(238, 286);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(470, 29);
            this.textBox_name.TabIndex = 34;
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Location = new System.Drawing.Point(904, 286);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(0, 13);
            this.label_id.TabIndex = 37;
            // 
            // comboBox_grafik
            // 
            this.comboBox_grafik.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_grafik.FormattingEnabled = true;
            this.comboBox_grafik.Items.AddRange(new object[] {
            "Полный рабочий день",
            "Сменный график",
            "Вахта",
            "Свободный график",
            "Удаленная работа",
            "Частичная занятость"});
            this.comboBox_grafik.Location = new System.Drawing.Point(238, 604);
            this.comboBox_grafik.Name = "comboBox_grafik";
            this.comboBox_grafik.Size = new System.Drawing.Size(470, 29);
            this.comboBox_grafik.TabIndex = 39;
            // 
            // label_grafik
            // 
            this.label_grafik.AutoSize = true;
            this.label_grafik.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_grafik.Location = new System.Drawing.Point(44, 607);
            this.label_grafik.Name = "label_grafik";
            this.label_grafik.Size = new System.Drawing.Size(125, 21);
            this.label_grafik.TabIndex = 38;
            this.label_grafik.Text = "График работы";
            // 
            // pictureBox_cancel
            // 
            this.pictureBox_cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_cancel.Image = global::НайтиРаботу.Properties.Resources.Canceladd;
            this.pictureBox_cancel.Location = new System.Drawing.Point(817, 713);
            this.pictureBox_cancel.Name = "pictureBox_cancel";
            this.pictureBox_cancel.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_cancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_cancel.TabIndex = 33;
            this.pictureBox_cancel.TabStop = false;
            this.pictureBox_cancel.Click += new System.EventHandler(this.pictureBox_cancel_Click);
            this.pictureBox_cancel.MouseEnter += new System.EventHandler(this.pictureBox_cancel_MouseEnter);
            this.pictureBox_cancel.MouseLeave += new System.EventHandler(this.pictureBox_cancel_MouseLeave);
            // 
            // pictureBox_confirm
            // 
            this.pictureBox_confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_confirm.Image = global::НайтиРаботу.Properties.Resources.apply;
            this.pictureBox_confirm.Location = new System.Drawing.Point(907, 711);
            this.pictureBox_confirm.Name = "pictureBox_confirm";
            this.pictureBox_confirm.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_confirm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_confirm.TabIndex = 32;
            this.pictureBox_confirm.TabStop = false;
            this.pictureBox_confirm.Click += new System.EventHandler(this.pictureBox_confirm_Click);
            this.pictureBox_confirm.MouseEnter += new System.EventHandler(this.pictureBox_confirm_MouseEnter);
            this.pictureBox_confirm.MouseLeave += new System.EventHandler(this.pictureBox_confirm_MouseLeave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(44, 660);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 42);
            this.label1.TabIndex = 43;
            this.label1.Text = "Профессиональные \r\nнавыки и знания";
            // 
            // nav
            // 
            this.nav.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nav.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nav.Location = new System.Drawing.Point(238, 660);
            this.nav.Name = "nav";
            this.nav.Size = new System.Drawing.Size(470, 29);
            this.nav.TabIndex = 42;
            // 
            // EditResumeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(970, 522);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nav);
            this.Controls.Add(this.comboBox_grafik);
            this.Controls.Add(this.label_grafik);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.pictureBox_cancel);
            this.Controls.Add(this.pictureBox_confirm);
            this.Controls.Add(this.comboBox_edu);
            this.Controls.Add(this.label_edu);
            this.Controls.Add(this.label_sal);
            this.Controls.Add(this.textBox_sal);
            this.Controls.Add(this.label_dol);
            this.Controls.Add(this.textBox_dol);
            this.Controls.Add(this.label_mail);
            this.Controls.Add(this.textBox_mail);
            this.Controls.Add(this.ОтображениеДанных);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditResumeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.EditResumeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ОтображениеДанных)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_cancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_confirm)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_edu;
        private System.Windows.Forms.Label label_edu;
        private System.Windows.Forms.Label label_sal;
        private System.Windows.Forms.TextBox textBox_sal;
        private System.Windows.Forms.Label label_dol;
        private System.Windows.Forms.TextBox textBox_dol;
        private System.Windows.Forms.Label label_mail;
        private System.Windows.Forms.TextBox textBox_mail;
        private System.Windows.Forms.DataGridView ОтображениеДанных;
        private System.Windows.Forms.PictureBox pictureBox_confirm;
        private System.Windows.Forms.PictureBox pictureBox_cancel;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.ComboBox comboBox_grafik;
        private System.Windows.Forms.Label label_grafik;
        private System.Windows.Forms.ToolTip toolTip_confirm;
        private System.Windows.Forms.ToolTip toolTip_cancelorclose;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox nav;
    }
}