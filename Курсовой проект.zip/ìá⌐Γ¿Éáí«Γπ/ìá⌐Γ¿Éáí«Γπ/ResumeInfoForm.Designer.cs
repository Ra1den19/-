﻿namespace НайтиРаботу
{
    partial class ResumeInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResumeInfoForm));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.info = new System.Windows.Forms.Label();
            this.fam = new System.Windows.Forms.Label();
            this.im = new System.Windows.Forms.Label();
            this.ot = new System.Windows.Forms.Label();
            this.naim = new System.Windows.Forms.Label();
            this.dol = new System.Windows.Forms.Label();
            this.zar = new System.Windows.Forms.Label();
            this.obr = new System.Windows.Forms.Label();
            this.poch = new System.Windows.Forms.Label();
            this.graph = new System.Windows.Forms.Label();
            this.nav = new System.Windows.Forms.Label();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.info);
            this.flowLayoutPanel1.Controls.Add(this.fam);
            this.flowLayoutPanel1.Controls.Add(this.im);
            this.flowLayoutPanel1.Controls.Add(this.ot);
            this.flowLayoutPanel1.Controls.Add(this.naim);
            this.flowLayoutPanel1.Controls.Add(this.dol);
            this.flowLayoutPanel1.Controls.Add(this.zar);
            this.flowLayoutPanel1.Controls.Add(this.obr);
            this.flowLayoutPanel1.Controls.Add(this.poch);
            this.flowLayoutPanel1.Controls.Add(this.graph);
            this.flowLayoutPanel1.Controls.Add(this.nav);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(5, 5, 0, 0);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(643, 449);
            this.flowLayoutPanel1.TabIndex = 0;
            this.flowLayoutPanel1.WrapContents = false;
            // 
            // info
            // 
            this.info.AutoSize = true;
            this.info.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.info.Location = new System.Drawing.Point(8, 5);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(290, 30);
            this.info.TabIndex = 0;
            this.info.Text = "Информация о соискателе";
            // 
            // fam
            // 
            this.fam.AutoSize = true;
            this.fam.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.fam.Location = new System.Drawing.Point(8, 35);
            this.fam.Name = "fam";
            this.fam.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.fam.Size = new System.Drawing.Size(80, 31);
            this.fam.TabIndex = 2;
            this.fam.Text = "Фамилия";
            // 
            // im
            // 
            this.im.AutoSize = true;
            this.im.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.im.Location = new System.Drawing.Point(8, 66);
            this.im.Name = "im";
            this.im.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.im.Size = new System.Drawing.Size(43, 31);
            this.im.TabIndex = 3;
            this.im.Text = "Имя";
            // 
            // ot
            // 
            this.ot.AutoSize = true;
            this.ot.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ot.Location = new System.Drawing.Point(8, 97);
            this.ot.Name = "ot";
            this.ot.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.ot.Size = new System.Drawing.Size(81, 31);
            this.ot.TabIndex = 4;
            this.ot.Text = "Отчество";
            // 
            // naim
            // 
            this.naim.AutoSize = true;
            this.naim.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.naim.Location = new System.Drawing.Point(8, 128);
            this.naim.Name = "naim";
            this.naim.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.naim.Size = new System.Drawing.Size(190, 31);
            this.naim.TabIndex = 5;
            this.naim.Text = "Наименование резюме";
            // 
            // dol
            // 
            this.dol.AutoSize = true;
            this.dol.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dol.Location = new System.Drawing.Point(8, 159);
            this.dol.Name = "dol";
            this.dol.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.dol.Size = new System.Drawing.Size(176, 31);
            this.dol.TabIndex = 6;
            this.dol.Text = "Желаемая должность";
            // 
            // zar
            // 
            this.zar.AutoSize = true;
            this.zar.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.zar.Location = new System.Drawing.Point(8, 190);
            this.zar.Name = "zar";
            this.zar.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.zar.Size = new System.Drawing.Size(78, 31);
            this.zar.TabIndex = 7;
            this.zar.Text = "Зарплата";
            // 
            // obr
            // 
            this.obr.AutoSize = true;
            this.obr.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.obr.Location = new System.Drawing.Point(8, 221);
            this.obr.Name = "obr";
            this.obr.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.obr.Size = new System.Drawing.Size(111, 31);
            this.obr.TabIndex = 8;
            this.obr.Text = "Образование";
            // 
            // poch
            // 
            this.poch.AutoSize = true;
            this.poch.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.poch.Location = new System.Drawing.Point(8, 252);
            this.poch.Name = "poch";
            this.poch.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.poch.Size = new System.Drawing.Size(155, 31);
            this.poch.TabIndex = 9;
            this.poch.Text = "Электронная почта";
            // 
            // graph
            // 
            this.graph.AutoSize = true;
            this.graph.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.graph.Location = new System.Drawing.Point(8, 283);
            this.graph.Name = "graph";
            this.graph.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.graph.Size = new System.Drawing.Size(125, 31);
            this.graph.TabIndex = 10;
            this.graph.Text = "График работы";
            // 
            // nav
            // 
            this.nav.AutoSize = true;
            this.nav.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nav.Location = new System.Drawing.Point(8, 314);
            this.nav.Name = "nav";
            this.nav.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.nav.Size = new System.Drawing.Size(293, 41);
            this.nav.TabIndex = 11;
            this.nav.Text = "Профессиональные навыки и знания";
            // 
            // ResumeInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(643, 449);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ResumeInfoForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Найти Работу";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label info;
        private System.Windows.Forms.Label fam;
        private System.Windows.Forms.Label im;
        private System.Windows.Forms.Label ot;
        private System.Windows.Forms.Label naim;
        private System.Windows.Forms.Label dol;
        private System.Windows.Forms.Label zar;
        private System.Windows.Forms.Label obr;
        private System.Windows.Forms.Label poch;
        private System.Windows.Forms.Label graph;
        private System.Windows.Forms.Label nav;
    }
}