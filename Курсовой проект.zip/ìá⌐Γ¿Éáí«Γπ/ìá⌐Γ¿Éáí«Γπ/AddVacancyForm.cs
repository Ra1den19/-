﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class AddVacancyForm : Form
    {
        int userId = AuthForm.UserId;
        public AddVacancyForm()
        {
            InitializeComponent();
            toolTip_add.SetToolTip(pictureBox_addvacancy, "Добавить");
            toolTip_cancel.SetToolTip(pictureBox_cancel, "Закрыть");
        }

        private void pictureBox_addvacancy_Click(object sender, EventArgs e)
        {
            try
            {
                string name = textBox_spec.Text;
                string city = textBox_city.Text;
                bool student = checkBox_stud.Checked;
                string exp = comboBox_exp.SelectedItem.ToString();
                string graph = comboBox_graph.SelectedItem.ToString();
                string salary = textBox_sal.Text;
                string edu = comboBox_edu.SelectedItem.ToString();
                string otrasl = comboBox_otr.SelectedItem.ToString();

                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                if (checkBox_stud.Checked == true)
                {
                    string query = $"insert into Вакансии(КодПользователя, Специализация, Город, Студентам, ОпытРаботы, ГрафикРаботы, Отрасль, Зарплата, Образование, Статус) values('{userId}' ,'{name}', '{city}', 'Да', '{exp}', '{graph}', '{otrasl}', '{salary}', '{edu}', 'Открыта'); select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], Отрасль, Зарплата, Образование, ГрафикРаботы as [График работы], Статус from Вакансии where КодПользователя = '{userId}'";
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    MessageBox.Show("Вакансия успешно добавлена", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else if (checkBox_stud.Checked == false) 
                {
                    string query = $"insert into Вакансии(КодПользователя, Специализация, Город, Студентам, ОпытРаботы, ГрафикРаботы, Отрасль, Зарплата, Образование, Статус) values('{userId}' ,'{name}', '{city}', 'Нет', '{exp}', '{graph}', '{otrasl}', '{salary}', '{edu}', 'Открыта'); select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], Отрасль, Зарплата, Образование, ГрафикРаботы as [График работы], Статус from Вакансии where КодПользователя = '{userId}'";
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    MessageBox.Show("Вакансия успешно добавлена", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddVacancyForm_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            string query = $"select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], Отрасль, Зарплата, Образование, ГрафикРаботы as [График работы], Статус from Вакансии where КодПользователя = '{userId}'";
            SqlCommand com = new SqlCommand(query, con);
            SqlDataAdapter adapter = new SqlDataAdapter(com);
        }

        private void pictureBox_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox_cancel_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_cancel.BackColor = Color.Silver;
        }

        private void pictureBox_cancel_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_cancel.BackColor = Color.White;
        }

        private void pictureBox_addvacancy_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_addvacancy.BackColor = Color.Silver;
        }

        private void pictureBox_addvacancy_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_addvacancy.BackColor = Color.White;
        }
    }
}
