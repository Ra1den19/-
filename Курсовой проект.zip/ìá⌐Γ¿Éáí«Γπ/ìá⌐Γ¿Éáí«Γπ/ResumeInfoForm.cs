﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class ResumeInfoForm : Form
    {
        public ResumeInfoForm(string[] data)
        {
            InitializeComponent();
            if (data.Length >= 11)
            {
                fam.Text = $"Фамилия: {data[1]}";
                im.Text = $"Имя: {data[2]}";
                ot.Text = $"Отчество: {data[3]}";
                naim.Text = $"Наименование резюме: {data[4]}";
                dol.Text = $"Желаемая должность: {data[5]}";
                zar.Text = $"Желаемая зарплата: {data[6]}";
                obr.Text = $"Образование: {data[7]}";
                poch.Text = $"Электронная почта: {data[8]}";
                graph.Text = $"График работы: {data[9]}";
                nav.Text = $"Профессиональные навыки и знания: {data[10]}";
            }
        }
    }
}
