﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class RabotodatelForm : Form
    {
        public RabotodatelForm()
        {
            InitializeComponent();
            toolTip_exit.SetToolTip(pictureBox_closeapp, "Закрыть программу");
            toolTip_logout.SetToolTip(pictureBox_logout, "Выйти из учетной записи");
        }

        private void pictureBox_closeapp_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Закрыть программу?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void percab_button_Click(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.FromArgb(0, 64, 0);
                favresumes_button.BackColor = Color.Green;
                myotkliki_button.BackColor = Color.Green;
                resumes_button.BackColor = Color.Green;
                PerCabRabForm pcr = new PerCabRabForm();
                pcr.TopLevel = false;
                pcr.FormBorderStyle = FormBorderStyle.None;
                pcr.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(pcr);
                pcr.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_logout_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Выйти из учетной записи?", "Сообщение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void percab_button_MouseEnter(object sender, EventArgs e)
        {
            percab_button.ForeColor = Color.Red;
        }

        private void percab_button_MouseLeave(object sender, EventArgs e)
        {
            percab_button.ForeColor = Color.White;
        }

        private void favresumes_button_MouseEnter(object sender, EventArgs e)
        {
            favresumes_button.ForeColor = Color.Red;
        }

        private void favresumes_button_MouseLeave(object sender, EventArgs e)
        {
            favresumes_button.ForeColor = Color.White;
        }

        private void myotkliki_button_MouseEnter(object sender, EventArgs e)
        {
            myotkliki_button.ForeColor = Color.Red;
        }

        private void myotkliki_button_MouseLeave(object sender, EventArgs e)
        {
            myotkliki_button.ForeColor = Color.White;
        }

        private void resumes_button_MouseEnter(object sender, EventArgs e)
        {
            resumes_button.ForeColor = Color.Red;
        }

        private void resumes_button_MouseLeave(object sender, EventArgs e)
        {
            resumes_button.ForeColor = Color.White;
        }

        private void resumes_button_Click(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.Green;
                favresumes_button.BackColor = Color.Green;
                myotkliki_button.BackColor = Color.Green;
                resumes_button.BackColor = Color.FromArgb(0, 64, 0);
                ResumesForm rf = new ResumesForm();
                rf.TopLevel = false;
                rf.FormBorderStyle = FormBorderStyle.None;
                rf.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(rf);
                rf.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void myotkliki_button_Click(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.Green;
                favresumes_button.BackColor = Color.Green;
                myotkliki_button.BackColor = Color.FromArgb(0, 64, 0);
                resumes_button.BackColor = Color.Green;
                MyInvitesForm mi = new MyInvitesForm();
                mi.TopLevel = false;
                mi.FormBorderStyle = FormBorderStyle.None;
                mi.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(mi);
                mi.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void favresumes_button_Click(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.Green;
                favresumes_button.BackColor = Color.FromArgb(0, 64, 0);
                myotkliki_button.BackColor = Color.Green;
                resumes_button.BackColor = Color.Green;
                FavResumesForm fr = new FavResumesForm();
                fr.TopLevel = false;
                fr.FormBorderStyle = FormBorderStyle.None;
                fr.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(fr);
                fr.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RabotodatelForm_Load(object sender, EventArgs e)
        {
            try
            {
                percab_button.BackColor = Color.FromArgb(0, 64, 0);
                favresumes_button.BackColor = Color.Green;
                myotkliki_button.BackColor = Color.Green;
                resumes_button.BackColor = Color.Green;
                PerCabRabForm pcr = new PerCabRabForm();
                pcr.TopLevel = false;
                pcr.FormBorderStyle = FormBorderStyle.None;
                pcr.Dock = DockStyle.Fill;
                panel1.Controls.Clear();
                panel1.Controls.Add(pcr);
                pcr.Show();
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_closeapp_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_closeapp.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBox_closeapp_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_closeapp.BackColor = Color.Green;
        }

        private void pictureBox_logout_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_logout.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBox_logout_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_logout.BackColor = Color.Green;
        }
    }
}
