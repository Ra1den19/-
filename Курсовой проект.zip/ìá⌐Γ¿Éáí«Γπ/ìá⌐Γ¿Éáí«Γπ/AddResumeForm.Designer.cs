﻿namespace НайтиРаботу
{
    partial class AddResumeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddResumeForm));
            this.label_mail = new System.Windows.Forms.Label();
            this.textBox_mail = new System.Windows.Forms.TextBox();
            this.label_dol = new System.Windows.Forms.Label();
            this.textBox_dol = new System.Windows.Forms.TextBox();
            this.label_sal = new System.Windows.Forms.Label();
            this.textBox_sal = new System.Windows.Forms.TextBox();
            this.label_edu = new System.Windows.Forms.Label();
            this.comboBox_edu = new System.Windows.Forms.ComboBox();
            this.label_name = new System.Windows.Forms.Label();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.comboBox_grafik = new System.Windows.Forms.ComboBox();
            this.label_grafik = new System.Windows.Forms.Label();
            this.бД_НайтиРаботуDataSet = new НайтиРаботу.БД_НайтиРаботуDataSet();
            this.бДНайтиРаботуDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.toolTip_add = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_cancel = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox_cancel = new System.Windows.Forms.PictureBox();
            this.pictureBox_addresume = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nav = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.бД_НайтиРаботуDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.бДНайтиРаботуDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_cancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addresume)).BeginInit();
            this.SuspendLayout();
            // 
            // label_mail
            // 
            this.label_mail.AutoSize = true;
            this.label_mail.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_mail.Location = new System.Drawing.Point(44, 70);
            this.label_mail.Name = "label_mail";
            this.label_mail.Size = new System.Drawing.Size(67, 17);
            this.label_mail.TabIndex = 4;
            this.label_mail.Text = "Эл. почта";
            // 
            // textBox_mail
            // 
            this.textBox_mail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_mail.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_mail.Location = new System.Drawing.Point(47, 90);
            this.textBox_mail.Name = "textBox_mail";
            this.textBox_mail.Size = new System.Drawing.Size(470, 25);
            this.textBox_mail.TabIndex = 3;
            // 
            // label_dol
            // 
            this.label_dol.AutoSize = true;
            this.label_dol.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_dol.Location = new System.Drawing.Point(44, 132);
            this.label_dol.Name = "label_dol";
            this.label_dol.Size = new System.Drawing.Size(144, 17);
            this.label_dol.TabIndex = 10;
            this.label_dol.Text = "Желаемая должность";
            // 
            // textBox_dol
            // 
            this.textBox_dol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_dol.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_dol.Location = new System.Drawing.Point(47, 152);
            this.textBox_dol.Name = "textBox_dol";
            this.textBox_dol.Size = new System.Drawing.Size(470, 25);
            this.textBox_dol.TabIndex = 9;
            // 
            // label_sal
            // 
            this.label_sal.AutoSize = true;
            this.label_sal.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_sal.Location = new System.Drawing.Point(44, 197);
            this.label_sal.Name = "label_sal";
            this.label_sal.Size = new System.Drawing.Size(65, 17);
            this.label_sal.TabIndex = 12;
            this.label_sal.Text = "Зарплата";
            // 
            // textBox_sal
            // 
            this.textBox_sal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_sal.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_sal.Location = new System.Drawing.Point(47, 217);
            this.textBox_sal.Name = "textBox_sal";
            this.textBox_sal.Size = new System.Drawing.Size(470, 25);
            this.textBox_sal.TabIndex = 11;
            // 
            // label_edu
            // 
            this.label_edu.AutoSize = true;
            this.label_edu.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_edu.Location = new System.Drawing.Point(44, 259);
            this.label_edu.Name = "label_edu";
            this.label_edu.Size = new System.Drawing.Size(92, 17);
            this.label_edu.TabIndex = 15;
            this.label_edu.Text = "Образование";
            // 
            // comboBox_edu
            // 
            this.comboBox_edu.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_edu.FormattingEnabled = true;
            this.comboBox_edu.Items.AddRange(new object[] {
            "Среднее",
            "Среднее профессиональное",
            "Неполное высшее",
            "Высшее (бакалавр)",
            "Высшее (специалист)",
            "Высшее (магистр)",
            "Второе высшее",
            "Курсы переподготовки",
            "МВА",
            "Аспирантура",
            "Докторантура"});
            this.comboBox_edu.Location = new System.Drawing.Point(47, 279);
            this.comboBox_edu.Name = "comboBox_edu";
            this.comboBox_edu.Size = new System.Drawing.Size(470, 25);
            this.comboBox_edu.TabIndex = 16;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_name.Location = new System.Drawing.Point(44, 11);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(121, 17);
            this.label_name.TabIndex = 20;
            this.label_name.Text = "Название резюме";
            // 
            // textBox_name
            // 
            this.textBox_name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_name.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_name.Location = new System.Drawing.Point(47, 31);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(470, 25);
            this.textBox_name.TabIndex = 19;
            // 
            // comboBox_grafik
            // 
            this.comboBox_grafik.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_grafik.FormattingEnabled = true;
            this.comboBox_grafik.Items.AddRange(new object[] {
            "Полный рабочий день",
            "Сменный график",
            "Вахта",
            "Свободный график",
            "Удаленная работа",
            "Частичная занятость"});
            this.comboBox_grafik.Location = new System.Drawing.Point(47, 341);
            this.comboBox_grafik.Name = "comboBox_grafik";
            this.comboBox_grafik.Size = new System.Drawing.Size(470, 25);
            this.comboBox_grafik.TabIndex = 39;
            // 
            // label_grafik
            // 
            this.label_grafik.AutoSize = true;
            this.label_grafik.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_grafik.Location = new System.Drawing.Point(44, 321);
            this.label_grafik.Name = "label_grafik";
            this.label_grafik.Size = new System.Drawing.Size(103, 17);
            this.label_grafik.TabIndex = 38;
            this.label_grafik.Text = "График работы";
            // 
            // бД_НайтиРаботуDataSet
            // 
            this.бД_НайтиРаботуDataSet.DataSetName = "БД_НайтиРаботуDataSet";
            this.бД_НайтиРаботуDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // бДНайтиРаботуDataSetBindingSource
            // 
            this.бДНайтиРаботуDataSetBindingSource.DataSource = this.бД_НайтиРаботуDataSet;
            this.бДНайтиРаботуDataSetBindingSource.Position = 0;
            // 
            // pictureBox_cancel
            // 
            this.pictureBox_cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_cancel.Image = global::НайтиРаботу.Properties.Resources.Canceladd;
            this.pictureBox_cancel.Location = new System.Drawing.Point(608, 509);
            this.pictureBox_cancel.Name = "pictureBox_cancel";
            this.pictureBox_cancel.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_cancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_cancel.TabIndex = 18;
            this.pictureBox_cancel.TabStop = false;
            this.pictureBox_cancel.Click += new System.EventHandler(this.pictureBox_cancel_Click);
            this.pictureBox_cancel.MouseEnter += new System.EventHandler(this.pictureBox_cancel_MouseEnter);
            this.pictureBox_cancel.MouseLeave += new System.EventHandler(this.pictureBox_cancel_MouseLeave);
            // 
            // pictureBox_addresume
            // 
            this.pictureBox_addresume.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_addresume.Image = global::НайтиРаботу.Properties.Resources.apply;
            this.pictureBox_addresume.Location = new System.Drawing.Point(698, 509);
            this.pictureBox_addresume.Name = "pictureBox_addresume";
            this.pictureBox_addresume.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_addresume.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_addresume.TabIndex = 17;
            this.pictureBox_addresume.TabStop = false;
            this.pictureBox_addresume.Click += new System.EventHandler(this.pictureBox_addresume_Click);
            this.pictureBox_addresume.MouseEnter += new System.EventHandler(this.pictureBox_addresume_MouseEnter);
            this.pictureBox_addresume.MouseLeave += new System.EventHandler(this.pictureBox_addresume_MouseLeave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(44, 382);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 17);
            this.label1.TabIndex = 41;
            this.label1.Text = "Профессиональные навыки и знания";
            // 
            // nav
            // 
            this.nav.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nav.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nav.Location = new System.Drawing.Point(47, 402);
            this.nav.Multiline = true;
            this.nav.Name = "nav";
            this.nav.Size = new System.Drawing.Size(470, 84);
            this.nav.TabIndex = 40;
            // 
            // AddResumeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 556);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nav);
            this.Controls.Add(this.comboBox_grafik);
            this.Controls.Add(this.label_grafik);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.pictureBox_cancel);
            this.Controls.Add(this.pictureBox_addresume);
            this.Controls.Add(this.comboBox_edu);
            this.Controls.Add(this.label_edu);
            this.Controls.Add(this.label_sal);
            this.Controls.Add(this.textBox_sal);
            this.Controls.Add(this.label_dol);
            this.Controls.Add(this.textBox_dol);
            this.Controls.Add(this.label_mail);
            this.Controls.Add(this.textBox_mail);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddResumeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.бД_НайтиРаботуDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.бДНайтиРаботуDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_cancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_addresume)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private БД_НайтиРаботуDataSet бД_НайтиРаботуDataSet;
        private System.Windows.Forms.BindingSource бДНайтиРаботуDataSetBindingSource;
        private System.Windows.Forms.ToolTip toolTip_add;
        private System.Windows.Forms.ToolTip toolTip_cancel;
        public System.Windows.Forms.PictureBox pictureBox_addresume;
        public System.Windows.Forms.Label label_mail;
        public System.Windows.Forms.TextBox textBox_mail;
        public System.Windows.Forms.Label label_dol;
        public System.Windows.Forms.TextBox textBox_dol;
        public System.Windows.Forms.Label label_sal;
        public System.Windows.Forms.TextBox textBox_sal;
        public System.Windows.Forms.Label label_edu;
        public System.Windows.Forms.ComboBox comboBox_edu;
        public System.Windows.Forms.PictureBox pictureBox_cancel;
        public System.Windows.Forms.Label label_name;
        public System.Windows.Forms.TextBox textBox_name;
        public System.Windows.Forms.ComboBox comboBox_grafik;
        public System.Windows.Forms.Label label_grafik;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox nav;
    }
}