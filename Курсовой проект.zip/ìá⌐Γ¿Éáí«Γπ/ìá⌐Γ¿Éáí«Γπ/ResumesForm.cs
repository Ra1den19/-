﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class ResumesForm : Form
    {
        int userId = AuthForm.UserId;
        public ResumesForm()
        {
            InitializeComponent();
            toolTip_addfav.SetToolTip(pictureBox_addfav, "Добавить в избранное");
        }

        private void button_otklik_Click(object sender, EventArgs e)
        {
            if (ОтображениеДанных.Rows.Count > 0)
            {
                DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                string query = $"insert into Приглашения(КодПользователя, КодРезюме) values('{userId}', '{id}'); select КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Пользователи inner join Резюме on Пользователи.КодПользователя = Резюме.КодПользователя";
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                SqlCommand com = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
                MessageBox.Show("Приглашение отправлено", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void pictureBox_addfav_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"insert into ИзбранныеРезюме(КодПользователя, КодРезюме) values('{userId}', '{id}'); select КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Пользователи inner join Резюме on Пользователи.КодПользователя = Резюме.КодПользователя";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Резюме добавлено в избранное", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_sort_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                if (comboBox_sort.SelectedIndex == 0)
                {
                    string query = $"exec SortResumeBySalary";
                    SqlCommand command = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                }
                else if (comboBox_sort.SelectedIndex == 1)
                {
                    string query = $"exec SortResumeByEducation";
                    SqlCommand command = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                }
                else if (comboBox_sort.SelectedIndex == 2)
                {
                    string query = $"exec SortResumeByGraph";
                    SqlCommand command = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_filteredu_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string index = comboBox_filteredu.SelectedItem.ToString();
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Пользователи inner join Резюме on Пользователи.КодПользователя = Резюме.КодПользователя where Образование = '{index}'";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex) 
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_filtergraph_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string index = comboBox_filtergraph.SelectedItem.ToString();
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Пользователи inner join Резюме on Пользователи.КодПользователя = Резюме.КодПользователя where ГрафикРаботы = '{index}'";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResumesForm_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = $"select КодРезюме as Номер, Фамилия, Имя, Отчество, Наименование, ЖелаемаяДолжность as [Желаемая должность], Зарплата, Образование, ЭлПочта as [Электронная почта], ГрафикРаботы as [График работы], ПрофессиональныеНавыкиИЗнания as [Профессиональные навыки и знания] from Пользователи inner join Резюме on Пользователи.КодПользователя = Резюме.КодПользователя ";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox_addfav_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_addfav.BackColor = Color.Silver;
        }

        private void pictureBox_addfav_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_addfav.BackColor = Color.White;
        }

        private void ОтображениеДанных_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = ОтображениеДанных.Rows[e.RowIndex];

                string[] rowData = new string[selectedRow.Cells.Count];
                for (int i = 0; i < selectedRow.Cells.Count; i++)
                {
                    rowData[i] = selectedRow.Cells[i].Value?.ToString();
                }

                ResumeInfoForm resForm = new ResumeInfoForm(rowData);
                resForm.ShowDialog();
            }

        }
    }
}
