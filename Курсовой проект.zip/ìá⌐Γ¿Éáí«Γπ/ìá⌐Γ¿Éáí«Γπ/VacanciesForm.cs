﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace НайтиРаботу
{
    public partial class VacanciesForm : Form
    {
        int userId = AuthForm.UserId;
        public VacanciesForm()
        {
            InitializeComponent();
            toolTip_addfav.SetToolTip(pictureBox_addfav, "Добавить в избранное");
        }

        private void pictureBox_addfav_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"insert into ИзбранныеВакансии(КодПользователя, КодВакансии) values('{userId}', '{id}'); select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Вакансия добавлена в избранное", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_otklik_Click(object sender, EventArgs e)
        {
            try
            {
                if (ОтображениеДанных.Rows.Count > 0)
                {
                    DataGridViewRow selectedRow = ОтображениеДанных.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Номер"].Value);
                    string query = $"insert into Отклики(КодПользователя, КодВакансии) values('{userId}', '{id}'); select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии";
                    SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ОтображениеДанных.DataSource = dt;
                    MessageBox.Show("Вы успешно откикнулись на вакансию", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void VacanciesForm_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
                string query = "select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            catch (Exception ex)
            {
                DialogResult res = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_sort_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            if (comboBox_sort.SelectedIndex == 0)
            {
                string query = "exec SortBySalary";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            else if (comboBox_sort.SelectedIndex == 1)
            {
                string query = "exec SortByExp";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            else if (comboBox_sort.SelectedIndex == 2)
            {
                string query = "exec SortByGraph";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            else if (comboBox_sort.SelectedIndex == 3) 
            {
                string query = "exec SortByOtrasl";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
        }

        private void comboBox_filterexp_SelectedIndexChanged(object sender, EventArgs e)
        {
            string index = comboBox_filterexp.SelectedItem.ToString();
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            string query = $"select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии where ОпытРаботы = '{index}'";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            ОтображениеДанных.DataSource = dt;
        }

        private void comboBox_filterotrasli_SelectedIndexChanged(object sender, EventArgs e)
        {
            string index = comboBox_filterotrasli.SelectedItem.ToString();
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            string query = $"select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии where Отрасль = '{index}'";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            ОтображениеДанных.DataSource = dt;
        }

        private void checkBox_stud_CheckedChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            if (checkBox_stud.Checked == true)
            {
                string query = "exec Student";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
            else
            {
                string query = "select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии";
                SqlCommand command = new SqlCommand(query, con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                ОтображениеДанных.DataSource = dt;
            }
        }

        private void comboBox_filtergraph_SelectedIndexChanged(object sender, EventArgs e)
        {
            string index = comboBox_filtergraph.SelectedItem.ToString();
            SqlConnection con = new SqlConnection(DataBaseConfig.ConnectionString);
            string query = $"select КодВакансии as Номер, Специализация, Город, Студентам, ОпытРаботы as [Опыт работы], ГрафикРаботы as [График работы], Отрасль, Зарплата, Образование from Вакансии where ГрафикРаботы = '{index}'";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            ОтображениеДанных.DataSource = dt;
        }

        private void pictureBox_addfav_MouseEnter(object sender, EventArgs e)
        {
            pictureBox_addfav.BackColor = Color.Silver;
        }

        private void pictureBox_addfav_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_addfav.BackColor = Color.White;
        }
    }
}
